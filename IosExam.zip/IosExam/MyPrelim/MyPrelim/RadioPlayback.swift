import Foundation
import AVFoundation
import Combine

final class RadioPlayer: ObservableObject {
    static let shared = RadioPlayer()
    @Published var isPlaying: Bool = false
    @Published var currentStationName: String? = nil
    @Published var currentStationImage: String? = nil

    private var player: AVPlayer? = nil
    private let service = RadioBrowserService()

    @MainActor
    func play(stationName: String, imageName: String) async {
        currentStationName = stationName
        currentStationImage = imageName
        let url = await service.resolveFirstStation(named: stationName)
        guard let url = url else {
            pause()
            return
        }
        let item = AVPlayerItem(url: url)
        player = AVPlayer(playerItem: item)
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [])
        try? AVAudioSession.sharedInstance().setActive(true, options: [])
        player?.play()
        isPlaying = true
    }

    func pause() {
        player?.pause()
        isPlaying = false
    }

    func togglePlayPause() {
        if isPlaying { pause() }
        else if let name = currentStationName, let image = currentStationImage {
            Task { await play(stationName: name, imageName: image) }
        }
    }

    func setVolume(_ value: Float) { player?.volume = value }
}
