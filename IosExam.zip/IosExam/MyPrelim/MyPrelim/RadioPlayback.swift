import Foundation
import AVFoundation
import Combine

final class RadioPlayer: ObservableObject {
    static let shared = RadioPlayer()
    @Published var isPlaying: Bool = false
    @Published var currentStationName: String? = nil
    @Published var currentStationImage: String? = nil
    @Published var isLoading: Bool = false
    @Published var errorMessage: String? = nil

    private var player: AVPlayer? = nil
    private var playerItem: AVPlayerItem? = nil
    private var statusObserver: NSKeyValueObservation? = nil
    private var timeObserver: Any? = nil
    @Published var isBuffering: Bool = false
    @Published var connectionStatus: String = "Idle"
    private let service = RadioBrowserService()
    
    init() {
        setupAudioSession()
    }
    
    private func setupAudioSession() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [])
            try AVAudioSession.sharedInstance().setActive(true)
            print("✅ Audio session configured")
        } catch {
            print("❌ Audio session setup failed: \(error)")
        }
    }

    @MainActor
    func play(stationName: String, imageName: String) async {
        // Clear any previous errors
        errorMessage = nil
        isLoading = true
        
        currentStationName = stationName
        currentStationImage = imageName
        
        print("🔴 Starting playback for: \(stationName)")
        
        let url = await service.resolveFirstStation(named: stationName)
        
        isLoading = false
        
        guard let url = url else {
            errorMessage = "Failed to find station '\(stationName)'. Please try another station."
            print("❌ Failed to resolve station URL")
            pause()
            return
        }
        
        // Stop any existing playback
        player?.pause()
        statusObserver?.invalidate()
        
        // Create new player item and player
        let item = AVPlayerItem(url: url)
        playerItem = item
        player = AVPlayer(playerItem: item)
        
        // Set volume to ensure it's not muted
        player?.volume = 1.0
        
        // Observe player status
        statusObserver = item.observe(\.status, options: [.new]) { [weak self] item, _ in
            DispatchQueue.main.async {
                switch item.status {
                case .readyToPlay:
                    print("✅ Player ready to play")
                    self?.connectionStatus = "Connected & Playing"
                    self?.isBuffering = false
                    self?.player?.play()
                    self?.isPlaying = true
                case .failed:
                    let errorDesc = item.error?.localizedDescription ?? "Unknown error"
                    print("❌ Player failed: \(errorDesc)")
                    if let error = item.error as NSError? {
                        print("❌ Error domain: \(error.domain)")
                        print("❌ Error code: \(error.code)")
                        print("❌ Error info: \(error.userInfo)")
                    }
                    self?.errorMessage = "Playback failed: \(errorDesc)"
                    self?.connectionStatus = "Failed"
                    self?.isPlaying = false
                case .unknown:
                    print("⚠️ Player status unknown")
                    self?.connectionStatus = "Connecting..."
                    self?.isBuffering = true
                @unknown default:
                    break
                }
            }
        }
        
        // Add time observer to detect actual playback
        let interval = CMTime(seconds: 1, preferredTimescale: 1)
        timeObserver = player?.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak self] time in
            if time.seconds > 0 {
                self?.connectionStatus = "🎵 STREAMING ACTIVE (time: \(Int(time.seconds))s)"
                print("✅ Audio time progressing: \(time.seconds)s - STREAM IS WORKING!")
            }
        }
        
        // Start playing immediately
        connectionStatus = "Buffering..."
        isBuffering = true
        player?.play()
        isPlaying = true
        print("✅ Attempting to play: \(stationName)")
        print("🔊 Volume set to: \(player?.volume ?? 0)")
        print("💡 NOTE: If testing on Simulator, you may not hear audio even if it's working")
    }

    func pause() {
        player?.pause()
        isPlaying = false
        connectionStatus = "Paused"
        isBuffering = false
        if let observer = timeObserver {
            player?.removeTimeObserver(observer)
            timeObserver = nil
        }
        print("⏸️ Playback paused")
    }

    func togglePlayPause() {
        if isPlaying { pause() }
        else if let name = currentStationName, let image = currentStationImage {
            Task { await play(stationName: name, imageName: image) }
        }
    }

    func setVolume(_ value: Float) {
        player?.volume = value
        print("🔊 Volume set to: \(value)")
    }
    
    deinit {
        statusObserver?.invalidate()
        if let observer = timeObserver {
            player?.removeTimeObserver(observer)
        }
    }
}
