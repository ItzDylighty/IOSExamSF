import Foundation
import AVFoundation
import Combine

final class RadioPlayer: ObservableObject {
    static let shared = RadioPlayer()
    @Published var isPlaying: Bool = false
    @Published var currentStationName: String? = nil
    @Published var currentStationImage: String? = nil
    @Published var isLoading: Bool = false
    @Published var errorMessage: String? = nil

    private var player: AVPlayer? = nil
    private let service = RadioBrowserService()

    @MainActor
    func play(stationName: String, imageName: String) async {
        // Clear any previous errors
        errorMessage = nil
        isLoading = true
        
        currentStationName = stationName
        currentStationImage = imageName
        
        print("🔴 Starting playback for: \(stationName)")
        
        let url = await service.resolveFirstStation(named: stationName)
        
        isLoading = false
        
        guard let url = url else {
            errorMessage = "Failed to find station '\(stationName)'. Please try another station."
            print("❌ Failed to resolve station URL")
            pause()
            return
        }
        
        do {
            let item = AVPlayerItem(url: url)
            player = AVPlayer(playerItem: item)
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [])
            try AVAudioSession.sharedInstance().setActive(true, options: [])
            player?.play()
            isPlaying = true
            print("✅ Playing: \(stationName)")
        } catch {
            errorMessage = "Failed to initialize audio player: \(error.localizedDescription)"
            print("❌ Audio session error: \(error)")
            pause()
        }
    }

    func pause() {
        player?.pause()
        isPlaying = false
    }

    func togglePlayPause() {
        if isPlaying { pause() }
        else if let name = currentStationName, let image = currentStationImage {
            Task { await play(stationName: name, imageName: image) }
        }
    }

    func setVolume(_ value: Float) { player?.volume = value }
}
