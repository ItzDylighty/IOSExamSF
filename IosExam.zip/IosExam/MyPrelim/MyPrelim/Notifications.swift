import Foundation

extension Notification.Name {
    static let openPlayerSheet = Notification.Name("OpenPlayerSheet")
}
