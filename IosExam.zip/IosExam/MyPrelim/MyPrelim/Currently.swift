import SwiftUI

// Player View
struct PlayerView: View {
    @ObservedObject private var player = RadioPlayer.shared
    @State private var volume: Double = 0.5
    @State private var currentTagline: String = ""
    
    let taglines = [
        "Chill and Goodvibes",
        "Feel the rhythm",
        "Music for your soul"
    ]

    var body: some View {
        VStack(spacing: 30) {
            // Album artwork
            Rectangle()
                .fill(Color.gray.opacity(0.3))
                .frame(width: 300, height: 300)
                .cornerRadius(12)
                .overlay(
                    Group {
                        if player.isLoading {
                            ProgressView()
                                .scaleEffect(2)
                        } else if let imageName = player.currentStationImage {
                            Image(imageName)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 300, height: 300)
                                .cornerRadius(12)
                        } else {
                            Image(systemName: "music.note")
                                .resizable()
                                .scaledToFit()
                                .foregroundColor(.primary.opacity(0.7))
                                .frame(width: 80, height: 80)
                        }
                    }
                )
                .padding(.top, 40)

            // Track info
            VStack(spacing: 8) {
                Text(player.currentStationName ?? "No playing")
                    .font(.title2)
                    .fontWeight(.bold)
                
                if let error = player.errorMessage {
                    Text(error)
                        .font(.caption)
                        .foregroundColor(.red)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                } else if player.isLoading {
                    Text("Loading station...")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                } else if player.isBuffering {
                    Text("Buffering stream...")
                        .font(.subheadline)
                        .foregroundColor(.orange)
                } else if player.currentStationName != nil {
                    Text(currentTagline)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                } else {
                    Text("Select a station to play")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                
                // Connection Status Indicator
                if player.connectionStatus != "Idle" && player.connectionStatus != "Paused" {
                    HStack(spacing: 4) {
                        Circle()
                            .fill(player.connectionStatus.contains("STREAMING") ? Color.green : Color.orange)
                            .frame(width: 8, height: 8)
                        Text(player.connectionStatus)
                            .font(.caption2)
                            .foregroundColor(player.connectionStatus.contains("STREAMING") ? .green : .orange)
                    }
                    .padding(.top, 4)
                    
                }
            }

            // Volume + controls
            VStack(spacing: 20) {
                HStack {
                    Image(systemName: "speaker.fill")
                    Slider(value: $volume, in: 0...1)
                    Image(systemName: "speaker.wave.3.fill")
                }
                .foregroundColor(.secondary)

                HStack(spacing: 50) {
                    Button(action: { player.playPrevious() }) {
                        Image(systemName: "backward.fill")
                            .font(.largeTitle)
                    }
                    Button(action: { player.togglePlayPause() }) {
                        Image(systemName: player.isPlaying ? "pause.circle.fill" : "play.circle.fill")
                            .font(.system(size: 60))
                    }
                    Button(action: { player.playNext() }) {
                        Image(systemName: "forward.fill")
                            .font(.largeTitle)
                    }
                }
                .foregroundColor(.blue)
            }

            Spacer()
        }
        .padding()
        .onAppear { 
            player.setVolume(Float(volume))
            currentTagline = taglines.randomElement() ?? "Chill and Goodvibes"
        }
        .onChange(of: volume) { _, newValue in
            player.setVolume(Float(newValue))
        }
        .onChange(of: player.currentStationName) { _, _ in
            currentTagline = taglines.randomElement() ?? "Chill and Goodvibes"
        }
    }
}

#Preview {
    PlayerView()
}

