import SwiftUI
import SwiftData

// Home Screen
struct HomeView: View {
    @Environment(\.modelContext) private var context
    @Query private var users: [User]
    @State private var profileImageData: Data? = nil
    @ObservedObject private var player = RadioPlayer.shared
    
    @State private var listenerCounts: [String: Int] = [
        "Wish 107.5": 12480,
        "Love Radio": 8320,
        "Monster": 6120,
        "Yes FM": 4500
    ]
    
    @State private var shuffledNewsStations: [(imageName: String, stationName: String, color: Color)] = []
    @State private var shuffledOtherStations: [(imageName: String, stationName: String, color: Color)] = []
    
    let newsStations = [
        (imageName: "Dzrm", stationName: "DZRM 612", color: Color.red),
        (imageName: "Yes", stationName: "Yes FM", color: Color.green),
        (imageName: "Love", stationName: "Love Radio", color: Color.blue),
        (imageName: "Veritas", stationName: "Veritas", color: Color.orange),
        (imageName: "Easyrock", stationName: "Easy Rock", color: Color.green)
    ]
    
    let otherStations = [
        (imageName: "Wish", stationName: "Wish 107.5", color: Color.red),
        (imageName: "Yes", stationName: "Yes FM", color: Color.green),
        (imageName: "Love", stationName: "Love Radio", color: Color.blue),
        (imageName: "Veritas", stationName: "Veritas", color: Color.orange),
        (imageName: "Easyrock", stationName: "Easy Rock", color: Color.green)
    ]
    
    let timer = Timer.publish(every: 10, on: .main, in: .common).autoconnect()

    var body: some View {
        VStack(spacing: 0) {

            //Header
            HStack {
                Text("Home")
                    .font(.system(size: 28, weight: .bold))
                Spacer()

                // Show uploaded profile image if available
                if let data = profileImageData, let uiImage = UIImage(data: data) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .frame(width: 28, height: 28)
                        .clipShape(Circle())
                } else {
                    Image(systemName: "person.circle")
                        .resizable()
                        .frame(width: 28, height: 28)
                }
            }
            .padding(.horizontal)
            .padding(.top, 10)

            // Scrollable Content
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {

                    // On Air Section
                    VStack(alignment: .leading, spacing: 12) {
                        Text("On Air")
                            .font(.headline)
                            .padding(.horizontal)

                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 16) {
                                StationCardView(imageName: "Wish", title: "Wish 107.5", subtitle: "dreams come alive", listeners: formatListeners(listenerCounts["Wish 107.5"] ?? 12480), color: .red, onTap: {
                                    Task { await RadioPlayer.shared.play(stationName: "Wish 107.5", imageName: "Wish") }
                                    NotificationCenter.default.post(name: .openPlayerSheet, object: nil)
                                })
                                StationCardView(imageName: "Love", title: "Love Radio", subtitle: "Feel the love everyday!", listeners: formatListeners(listenerCounts["Love Radio"] ?? 8320), color: .pink, onTap: {
                                    Task { await RadioPlayer.shared.play(stationName: "Love Radio", imageName: "Love") }
                                    NotificationCenter.default.post(name: .openPlayerSheet, object: nil)
                                })
                                StationCardView(imageName: "Monster", title: "Monster", subtitle: "Top hits, non-stop", listeners: formatListeners(listenerCounts["Monster"] ?? 6120), color: .blue, onTap: {
                                    Task { await RadioPlayer.shared.play(stationName: "Monster", imageName: "Monster") }
                                    NotificationCenter.default.post(name: .openPlayerSheet, object: nil)
                                })
                                StationCardView(imageName: "Yes", title: "Yes FM", subtitle: "All hits all day", listeners: formatListeners(listenerCounts["Yes FM"] ?? 4500), color: .green, onTap: {
                                    Task { await RadioPlayer.shared.play(stationName: "Yes FM", imageName: "Yes") }
                                    NotificationCenter.default.post(name: .openPlayerSheet, object: nil)
                                })
                            }
                            .padding(.horizontal)
                        }
                    }

                    // Recently Listen
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("Recently Listen")
                                .font(.headline)
                            Spacer()
                            Button(action: {}) {
                                Text(">")
                                    .font(.headline)
                                    .foregroundColor(.primary)
                            }
                        }
                        .padding(.horizontal)

                        if player.recentlyPlayed.isEmpty {
                            Text("No recently played stations")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                                .padding(.horizontal)
                                .padding(.vertical, 20)
                        } else {
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 16) {
                                    ForEach(player.recentlyPlayed.indices, id: \.self) { index in
                                        let station = player.recentlyPlayed[index]
                                        let colors: [Color] = [.blue, .orange, .purple, .green, .pink, .red, .cyan, .indigo, .mint, .teal]
                                        MiniStationCard(imageName: station.image, color: colors[index % colors.count], onTap: {
                                            Task { await RadioPlayer.shared.play(stationName: station.name, imageName: station.image) }
                                            NotificationCenter.default.post(name: .openPlayerSheet, object: nil)
                                        })
                                    }
                                }
                                .padding(.horizontal)
                            }
                        }
                    }

                    // News Live
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("News Live")
                                .font(.headline)
                            Spacer()
                            Button(action: {}) {
                                Text(">")
                                    .font(.headline)
                                    .foregroundColor(.primary)
                            }
                        }
                        .padding(.horizontal)

                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 16) {
                                ForEach(shuffledNewsStations.indices, id: \.self) { index in
                                    let station = shuffledNewsStations[index]
                                    MiniStationCard(imageName: station.imageName, color: station.color, onTap: {
                                        Task { await RadioPlayer.shared.play(stationName: station.stationName, imageName: station.imageName) }
                                        NotificationCenter.default.post(name: .openPlayerSheet, object: nil)
                                    })
                                }
                            }
                            .padding(.horizontal)
                        }
                    }

                    // Others
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("Others")
                                .font(.headline)
                            Spacer()
                            Button(action: {}) {
                                Text(">")
                                    .font(.headline)
                                    .foregroundColor(.primary)
                            }
                        }
                        .padding(.horizontal)

                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 16) {
                                ForEach(shuffledOtherStations.indices, id: \.self) { index in
                                    let station = shuffledOtherStations[index]
                                    MiniStationCard(imageName: station.imageName, color: station.color, onTap: {
                                        Task { await RadioPlayer.shared.play(stationName: station.stationName, imageName: station.imageName) }
                                        NotificationCenter.default.post(name: .openPlayerSheet, object: nil)
                                    })
                                }
                            }
                            .padding(.horizontal)
                        }
                    }
                }
                .padding(.bottom, 140) // Space for bottom bar
            }
        }
        // Load current user's profile image
        .onAppear {
            if let currentUsername = UserDefaults.standard.string(forKey: "currentUsername"),
               let user = users.first(where: { $0.username == currentUsername }) {
                profileImageData = user.profileImage
            } else {
                profileImageData = nil
            }
            shuffleNewsStations()
            shuffleOtherStations()
        }
        .onReceive(timer) { _ in
            updateListenerCounts()
        }
    }
    
    private func updateListenerCounts() {
        for (station, baseCount) in listenerCounts {
            // Random change between -200 to +300
            let change = Int.random(in: -200...300)
            let newCount = max(1000, baseCount + change) // Minimum 1000 listeners
            listenerCounts[station] = newCount
        }
    }
    
    private func formatListeners(_ count: Int) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        return formatter.string(from: NSNumber(value: count)) ?? "\(count)"
    }
    
    private func shuffleNewsStations() {
        shuffledNewsStations = newsStations.shuffled()
    }
    
    private func shuffleOtherStations() {
        shuffledOtherStations = otherStations.shuffled()
    }
}

// Station Card View
struct StationCardView: View {
    var imageName: String
    var title: String
    var subtitle: String
    var listeners: String
    var color: Color
    var onTap: (() -> Void)? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            if let _ = UIImage(named: imageName) {
                Image(imageName)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 160, height: 100)
                    .clipped()
                    .cornerRadius(10)
            } else {
                Image(systemName: "photo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 160, height: 100)
                    .foregroundColor(.gray)
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
            }
            Text(title)
                .font(.headline)
            Text(subtitle)
                .font(.caption)
                .foregroundColor(.gray)
            Text("Active Listeners: \(listeners)")
                .font(.caption2)
                .foregroundColor(.orange)
        }
        .frame(width: 160)
        .onTapGesture { onTap?() }
    }
}

// Mini Card
struct MiniStationCard: View {
    var imageName: String
    var color: Color
    var onTap: (() -> Void)? = nil

    var body: some View {
        Rectangle()
            .fill(color)
            .frame(width: 100, height: 100)
            .overlay(
                Image(imageName)
                    .resizable()
                    .scaledToFit()
                    .foregroundColor(.white.opacity(0.9))
                    .frame(width: 100, height: 100)
            )
            .cornerRadius(12)
            .onTapGesture { onTap?() }
    }
}

// Currently Playing Bar
struct CurrentlyPlayingBar: View {
    @StateObject private var player = RadioPlayer.shared
    var body: some View {
        HStack {
            Rectangle()
                .fill(Color.gray.opacity(0.3))
                .frame(width: 50, height: 50)
                .cornerRadius(8)
                .overlay(
                    Group {
                        if let imageName = player.currentStationImage {
                            Image(imageName)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 50, height: 50)
                                .cornerRadius(8)
                        } else {
                            Image(systemName: "music.note")
                                .foregroundColor(.primary)
                        }
                    }
                )
            VStack(alignment: .leading) {
                if let stationName = player.currentStationName {
                    Text("Now Playing: \(stationName)")
                        .font(.subheadline)
                        .foregroundColor(.primary)
                    Text(player.isPlaying ? "Chill and Goodvibes" : "Paused")
                        .font(.caption)
                        .foregroundColor(.secondary)
                } else {
                    Text("No playing")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Text("Select a station to play")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            Spacer()
            Button(action: { player.togglePlayPause() }) {
                Image(systemName: player.isPlaying ? "pause.fill" : "play.fill")
                    .font(.title2)
                    .foregroundColor(.blue)
            }
        }
        .padding()
        .background(Color(.systemBackground).shadow(radius: 2))
        .overlay(
            Rectangle()
                .frame(height: 0.5)
                .foregroundColor(Color(.separator)),
            alignment: .top
        )
    }
}

// Bottom Navigation Bar
struct BottomNavBar: View {
    @Binding var selectedTab: Int
    var body: some View {
        HStack {
            Spacer()
            Button(action: { selectedTab = 0 }) {
                VStack {
                    Image(systemName: "house.fill")
                    Text("Home").font(.caption2)
                }
                .foregroundColor(selectedTab == 0 ? .blue : .secondary)
            }
            Spacer()
            Button(action: { selectedTab = 1 }) {
                VStack {
                    Image(systemName: "magnifyingglass")
                    Text("Search").font(.caption2)
                }
                .foregroundColor(selectedTab == 1 ? .blue : .secondary)
            }
            Spacer()
            Button(action: { selectedTab = 2 }) {
                VStack {
                    Image(systemName: "person.fill")
                    Text("Profile").font(.caption2)
                }
                .foregroundColor(selectedTab == 2 ? .blue : .secondary)
            }
            Spacer()
        }
        .padding(.vertical, 8)
        .background(Color(.systemBackground).shadow(radius: 2))
        .overlay(
            Rectangle()
                .frame(height: 0.5)
                .foregroundColor(Color(.separator)),
            alignment: .top
        )
    }
}

// Main View
struct MainTabView: View {
    @State private var selectedTab = 0
    @State private var showPlayer = false // for sheet

    var body: some View {
        NavigationStack {
            ZStack(alignment: .bottom) {

                // Screen Switching
                Group {
                    if selectedTab == 0 {
                        HomeView()
                    } else if selectedTab == 1 {
                        SearchView()
                    } else {
                        ProfileView()
                    }
                }

            // Fixed Bottom Player + Navigation
            VStack(spacing: 0) {
                Spacer()
                // Tap on bar opens sheet
                CurrentlyPlayingBar()
                    .onTapGesture { showPlayer.toggle() }
                BottomNavBar(selectedTab: $selectedTab)
            }
        }
        .navigationBarBackButtonHidden(true)
        .edgesIgnoringSafeArea(.bottom)
        // Sheet presentation
        .sheet(isPresented: $showPlayer) {
            PlayerView()
                .presentationDetents([.medium, .large], selection: .constant(.large))
                .presentationDragIndicator(.visible)
        }
        .onReceive(NotificationCenter.default.publisher(for: .openPlayerSheet)) { _ in
            showPlayer = true
        }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        MainTabView()
            .preferredColorScheme(.light)
            .environmentObject(AppState())
    }
}

// News Live Detail View
struct NewsLiveDetailView: View {
    @Environment(\.dismiss) private var dismiss
    
    let newsStations = [
        (imageName: "Dzrm", stationName: "DZRM 612", color: Color.red),
        (imageName: "Yes", stationName: "Yes FM", color: Color.green),
        (imageName: "Love", stationName: "Love Radio", color: Color.blue),
        (imageName: "Veritas", stationName: "Veritas", color: Color.orange),
        (imageName: "Easyrock", stationName: "Easy Rock", color: Color.green),
        (imageName: "Monster", stationName: "Monster FM", color: Color.purple),
        (imageName: "Wish", stationName: "Wish 107.5", color: Color.red)
    ]
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Button(action: {
                    dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .font(.title2)
                        .foregroundColor(.primary)
                }
                
                Text("News Live")
                    .font(.system(size: 28, weight: .bold))
                
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top, 10)
            .padding(.bottom, 20)
            
            // Stations Grid
            ScrollView {
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 20) {
                    ForEach(newsStations.indices, id: \.self) { index in
                        let station = newsStations[index]
                        VStack {
                            Rectangle()
                                .fill(station.color)
                                .frame(width: 150, height: 150)
                                .overlay(
                                    Image(station.imageName)
                                        .resizable()
                                        .scaledToFit()
                                        .foregroundColor(.white.opacity(0.9))
                                        .frame(width: 150, height: 150)
                                )
                                .cornerRadius(12)
                            
                            Text(station.stationName)
                                .font(.headline)
                                .foregroundColor(.primary)
                        }
                        .onTapGesture {
                            Task { await RadioPlayer.shared.play(stationName: station.stationName, imageName: station.imageName) }
                            NotificationCenter.default.post(name: .openPlayerSheet, object: nil)
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.bottom, 100)
            }
        }
        .navigationBarHidden(true)
    }
}

// Others Detail View
struct OthersDetailView: View {
    @Environment(\.dismiss) private var dismiss
    
    let otherStations = [
        (imageName: "Wish", stationName: "Wish 107.5", color: Color.red),
        (imageName: "Yes", stationName: "Yes FM", color: Color.green),
        (imageName: "Love", stationName: "Love Radio", color: Color.blue),
        (imageName: "Veritas", stationName: "Veritas", color: Color.orange),
        (imageName: "Easyrock", stationName: "Easy Rock", color: Color.green),
        (imageName: "Monster", stationName: "Monster FM", color: Color.purple),
        (imageName: "Radyo5", stationName: "Radyo 5", color: Color.blue),
        (imageName: "Barangay", stationName: "Barangay LS 97.1", color: Color.orange)
    ]
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Button(action: {
                    dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .font(.title2)
                        .foregroundColor(.primary)
                }
                
                Text("Others")
                    .font(.system(size: 28, weight: .bold))
                
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top, 10)
            .padding(.bottom, 20)
            
            // Stations Grid
            ScrollView {
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 20) {
                    ForEach(otherStations.indices, id: \.self) { index in
                        let station = otherStations[index]
                        VStack {
                            Rectangle()
                                .fill(station.color)
                                .frame(width: 150, height: 150)
                                .overlay(
                                    Image(station.imageName)
                                        .resizable()
                                        .scaledToFit()
                                        .foregroundColor(.white.opacity(0.9))
                                        .frame(width: 150, height: 150)
                                )
                                .cornerRadius(12)
                            
                            Text(station.stationName)
                                .font(.headline)
                                .foregroundColor(.primary)
                        }
                        .onTapGesture {
                            Task { await RadioPlayer.shared.play(stationName: station.stationName, imageName: station.imageName) }
                            NotificationCenter.default.post(name: .openPlayerSheet, object: nil)
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.bottom, 100)
            }
        }
        .navigationBarHidden(true)
    }
}

#Preview {
    HomeView()
}
