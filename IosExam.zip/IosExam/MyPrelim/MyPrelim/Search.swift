import SwiftUI
import SwiftData

struct Station: Identifiable {
    let id = UUID()
    let name: String
    let image: String
}

struct SearchView: View {
    @State private var searchText = ""
    @Query private var users: [User]
    @State private var profileImageData: Data? = nil

    let stations = [
        Station(name: "DZRM 612", image: "Dzrm"),
        Station(name: "Monster FM", image: "Monster"),
        Station(name: "Yes FM", image: "Yes"),
        Station(name: "Veritas", image: "Veritas"),
        Station(name: "Wish 107.5", image: "Wish"),
        Station(name: "Easy Rock", image: "Easyrock"),
        Station(name: "Love Radio", image: "Love"),
        Station(name: "Radyo 5", image: "Radyo5"),
        Station(name: "Barangay LS 97.1", image: "Barangay"),
        Station(name: "Home Radio", image: "Home"),
        Station(name: "Energy FM", image: "Energy"),
        Station(name: "Brigada News FM", image: "Brigada"),
        Station(name: "Radyo Natin", image: "RadyoNatin")
    ]

    var filteredStations: [Station] {
        if searchText.isEmpty {
            return stations
        } else {
            return stations.filter { $0.name.lowercased().contains(searchText.lowercased()) }
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            // Fixed Header
            HStack {
                Text("Search")
                    .font(.system(size: 28, weight: .bold))

                Spacer()

                // Show saved profile photo if available, else default icon
                if let data = profileImageData,
                   let uiImage = UIImage(data: data) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .frame(width: 28, height: 28)
                        .clipShape(Circle())
                } else {
                    Image(systemName: "person.circle")
                        .resizable()
                        .frame(width: 28, height: 28)
                }
            }
            .padding(.horizontal)
            .padding(.top, 10)

            // Search Bar
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.gray)
                TextField("Search", text: $searchText)
            }
            .padding()
            .background(Color(.systemGray6))
            .cornerRadius(10)
            .padding(.horizontal)

            // Main Scroll Area
            ScrollView(.vertical, showsIndicators: true) {
                VStack(alignment: .leading, spacing: 20) {

                    if filteredStations.isEmpty {
                        Text("Station Not Found")
                            .font(.headline)
                            .foregroundColor(.gray)
                            .frame(maxWidth: .infinity, minHeight: 200, alignment: .center)
                    } else {
                        // Featured Stations
                        Text("Featured Stations")
                            .font(.headline)
                            .padding(.horizontal)

                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 16) {
                                ForEach(filteredStations) { station in
                                    VStack {
                                        Image(station.image)
                                            .resizable()
                                            .aspectRatio(contentMode: .fill)
                                            .frame(width: 120, height: 120)
                                            .cornerRadius(12)

                                        Text(station.name)
                                            .font(.caption)
                                            .foregroundColor(.primary)
                                    }
                                    .onTapGesture {
                                        Task { await RadioPlayer.shared.play(stationName: station.name, imageName: station.image) }
                                        NotificationCenter.default.post(name: .openPlayerSheet, object: nil)
                                    }
                                }
                            }
                            .padding(.horizontal)
                        }

                        // All Stations
                        Text("All Stations")
                            .font(.headline)
                            .padding(.horizontal)

                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
                            ForEach(filteredStations) { station in
                                VStack {
                                    Image(station.image)
                                        .resizable()
                                        .aspectRatio(contentMode: .fill)
                                        .frame(width: 150, height: 150)
                                        .cornerRadius(8)

                                    Text(station.name)
                                        .font(.caption)
                                        .foregroundColor(.primary)
                                }
                                .onTapGesture {
                                    Task { await RadioPlayer.shared.play(stationName: station.name, imageName: station.image) }
                                    NotificationCenter.default.post(name: .openPlayerSheet, object: nil)
                                }
                            }
                        }
                        .padding(.horizontal)
                    }
                }
                .padding(.vertical)
            }

            Spacer()
        }
        .onAppear {
            if let currentUsername = UserDefaults.standard.string(forKey: "currentUsername"),
               let user = users.first(where: { $0.username == currentUsername }) {
                profileImageData = user.profileImage
            } else {
                profileImageData = nil
            }
        }
    }
}

#Preview {
    SearchView()
}
