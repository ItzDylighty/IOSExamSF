import SwiftUI
import SwiftData

@main
struct RadioApp: App {
    @StateObject private var appState = AppState()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(appState)
        }
        .modelContainer(for: User.self)
    }
}
