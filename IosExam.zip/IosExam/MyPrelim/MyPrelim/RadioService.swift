import Foundation

final class RadioBrowserService {
    private let base = URL(string: "https://de1.api.radio-browser.info/json")!

    struct StationDTO: Decodable {
        let name: String
        let url_resolved: String?
        let favicon: String?
        let country: String?
        let countrycode: String?
    }
    
    // Fallback direct stream URLs for popular Philippine stations
    // Using reliable streaming sources that work in iOS Simulator
    private let fallbackStreams: [String: String] = [
        // Test stream that works in simulator (BBC Radio)
        "test": "http://stream.live.vc.bbcmedia.co.uk/bbc_world_service",
        // Philippine stations
        "wish": "https://stream.zeno.fm/f3wvbbqmdg8uv",
        "love": "https://stream.zeno.fm/0r0xa792kwzuv",
        "monster": "https://stream.zeno.fm/d8tftm0km8duv",
        "yes": "https://stream.zeno.fm/8khbm0rqgg8uv",
        "easy": "https://stream.zeno.fm/n83wdpbvg3duv",
        "dzrm": "https://stream.zeno.fm/7w3rb0z7ptzuv",
        "veritas": "https://stream.zeno.fm/8f0ccnz0k18uv",
        "barangay": "https://node-25.zeno.fm/z81kztfqp98uv"
    ]

    func resolveFirstStation(named name: String) async -> URL? {
        print("🔍 Searching for station: \(name)")
        
        // Try fallback URLs first for known Philippine stations
        let normalizedName = name.lowercased()
        for (key, urlString) in fallbackStreams {
            if normalizedName.contains(key) {
                if let url = URL(string: urlString) {
                    print("✅ Using fallback stream for \(name)")
                    print("🎧 Stream URL: \(url.absoluteString)")
                    
                    // Verify URL is reachable
                    if await verifyURL(url) {
                        return url
                    } else {
                        print("⚠️ Fallback URL not reachable, trying API...")
                    }
                }
            }
        }
        
        // Try API search with Philippine country filter first
        if let url = await searchAPI(name: name, countryCode: "PH") {
            return url
        }
        
        // Try broader search without country filter
        print("⚠️ Retrying without country filter...")
        return await searchAPI(name: name, countryCode: nil)
    }
    
    private func verifyURL(_ url: URL) async -> Bool {
        do {
            var request = URLRequest(url: url)
            request.httpMethod = "HEAD"
            request.timeoutInterval = 5
            let (_, response) = try await URLSession.shared.data(for: request)
            if let http = response as? HTTPURLResponse {
                print("📊 URL status: \(http.statusCode)")
                return http.statusCode == 200 || http.statusCode == 206
            }
            return true // Assume it's okay if we can't verify
        } catch {
            print("⚠️ URL verification failed: \(error.localizedDescription)")
            return true // Still try to play it
        }
    }
    
    private func searchAPI(name: String, countryCode: String?) async -> URL? {
        var comps = URLComponents(url: base.appendingPathComponent("stations/search"), resolvingAgainstBaseURL: false)!
        
        var queryItems = [
            URLQueryItem(name: "name", value: name),
            URLQueryItem(name: "limit", value: "5"),
            URLQueryItem(name: "hidebroken", value: "true"),
            URLQueryItem(name: "order", value: "votes"),
            URLQueryItem(name: "reverse", value: "true")
        ]
        
        if let code = countryCode {
            queryItems.append(URLQueryItem(name: "countrycode", value: code))
        }
        
        comps.queryItems = queryItems
        
        guard let url = comps.url else {
            print("❌ Failed to construct URL")
            return nil
        }
        
        print("📡 API URL: \(url.absoluteString)")
        
        do {
            let (data, response) = try await URLSession.shared.data(from: url)
            guard let http = response as? HTTPURLResponse else {
                print("❌ Invalid HTTP response")
                return nil
            }
            
            print("📊 Response status: \(http.statusCode)")
            
            guard http.statusCode == 200 else {
                print("❌ HTTP error: \(http.statusCode)")
                return nil
            }
            
            let stations = try JSONDecoder().decode([StationDTO].self, from: data)
            print("✅ Found \(stations.count) station(s)")
            
            if stations.isEmpty {
                print("⚠️ No stations found for: \(name)")
                return nil
            }
            
            // Try each station until we find one with a valid URL
            for station in stations {
                print("🎵 Trying: \(station.name) [\(station.country ?? "Unknown")]")
                
                if let urlStr = station.url_resolved,
                   !urlStr.isEmpty,
                   let stream = URL(string: urlStr) {
                    print("🎧 Stream URL: \(stream.absoluteString)")
                    return stream
                }
            }
            
            print("❌ No valid stream URLs found")
            return nil
        } catch {
            print("❌ Error: \(error.localizedDescription)")
            return nil
        }
    }
}
