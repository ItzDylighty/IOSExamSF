import Foundation

final class RadioBrowserService {
    private let base = URL(string: "https://de1.api.radio-browser.info/json")!

    struct StationDTO: Decodable {
        let name: String
        let url_resolved: String?
        let favicon: String?
        let country: String?
        let countrycode: String?
    }
    
    // Fallback direct stream URLs for popular Philippine stations
    private let fallbackStreams: [String: String] = [
        "wish": "http://radio.garden/api/ara/content/listen/rVwoqJjJ/channel.mp3",
        "love": "http://radio.garden/api/ara/content/listen/f4EWQzQR/channel.mp3",
        "monster": "http://184.154.202.243:8015/stream",
        "yes": "http://radio.garden/api/ara/content/listen/EXwvy-Dl/channel.mp3",
        "easy": "http://radio.garden/api/ara/content/listen/M7Y9GV4q/channel.mp3",
        "dzrm": "http://radio.garden/api/ara/content/listen/c8XSpvk5/channel.mp3"
    ]

    func resolveFirstStation(named name: String) async -> URL? {
        print("🔍 Searching for station: \(name)")
        
        // Try fallback URLs first for known Philippine stations
        let normalizedName = name.lowercased()
        for (key, urlString) in fallbackStreams {
            if normalizedName.contains(key) {
                if let url = URL(string: urlString) {
                    print("✅ Using fallback stream for \(name)")
                    print("🎧 Stream URL: \(url.absoluteString)")
                    return url
                }
            }
        }
        
        // Try API search with Philippine country filter first
        if let url = await searchAPI(name: name, countryCode: "PH") {
            return url
        }
        
        // Try broader search without country filter
        print("⚠️ Retrying without country filter...")
        return await searchAPI(name: name, countryCode: nil)
    }
    
    private func searchAPI(name: String, countryCode: String?) async -> URL? {
        var comps = URLComponents(url: base.appendingPathComponent("stations/search"), resolvingAgainstBaseURL: false)!
        
        var queryItems = [
            URLQueryItem(name: "name", value: name),
            URLQueryItem(name: "limit", value: "5"),
            URLQueryItem(name: "hidebroken", value: "true"),
            URLQueryItem(name: "order", value: "votes"),
            URLQueryItem(name: "reverse", value: "true")
        ]
        
        if let code = countryCode {
            queryItems.append(URLQueryItem(name: "countrycode", value: code))
        }
        
        comps.queryItems = queryItems
        
        guard let url = comps.url else {
            print("❌ Failed to construct URL")
            return nil
        }
        
        print("📡 API URL: \(url.absoluteString)")
        
        do {
            let (data, response) = try await URLSession.shared.data(from: url)
            guard let http = response as? HTTPURLResponse else {
                print("❌ Invalid HTTP response")
                return nil
            }
            
            print("📊 Response status: \(http.statusCode)")
            
            guard http.statusCode == 200 else {
                print("❌ HTTP error: \(http.statusCode)")
                return nil
            }
            
            let stations = try JSONDecoder().decode([StationDTO].self, from: data)
            print("✅ Found \(stations.count) station(s)")
            
            if stations.isEmpty {
                print("⚠️ No stations found for: \(name)")
                return nil
            }
            
            // Try each station until we find one with a valid URL
            for station in stations {
                print("🎵 Trying: \(station.name) [\(station.country ?? "Unknown")]")
                
                if let urlStr = station.url_resolved,
                   !urlStr.isEmpty,
                   let stream = URL(string: urlStr) {
                    print("🎧 Stream URL: \(stream.absoluteString)")
                    return stream
                }
            }
            
            print("❌ No valid stream URLs found")
            return nil
        } catch {
            print("❌ Error: \(error.localizedDescription)")
            return nil
        }
    }
}
