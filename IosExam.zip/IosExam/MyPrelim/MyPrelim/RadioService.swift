import Foundation

final class RadioBrowserService {
    private let base = URL(string: "https://de1.api.radio-browser.info/json")!

    struct StationDTO: Decodable {
        let name: String
        let url_resolved: String?
        let favicon: String?
    }

    func resolveFirstStation(named name: String) async -> URL? {
        var comps = URLComponents(url: base.appendingPathComponent("/stations/search"), resolvingAgainstBaseURL: false)!
        comps.queryItems = [
            .init(name: "name", value: name),
            .init(name: "limit", value: "1"),
            .init(name: "hidebroken", value: "true")
        ]
        guard let url = comps.url else { return nil }
        do {
            let (data, response) = try await URLSession.shared.data(from: url)
            guard let http = response as? HTTPURLResponse, http.statusCode == 200 else { return nil }
            let stations = try JSONDecoder().decode([StationDTO].self, from: data)
            guard let first = stations.first, let urlStr = first.url_resolved, let stream = URL(string: urlStr) else {
                return nil
            }
            return stream
        } catch {
            return nil
        }
    }
}
