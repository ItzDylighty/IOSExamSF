import Foundation

final class RadioBrowserService {
    private let base = URL(string: "https://de1.api.radio-browser.info/json")!

    struct StationDTO: Decodable {
        let name: String
        let url_resolved: String?
        let favicon: String?
    }

    func resolveFirstStation(named name: String) async -> URL? {
        var comps = URLComponents(url: base.appendingPathComponent("stations/search"), resolvingAgainstBaseURL: false)!
        comps.queryItems = [
            .init(name: "name", value: name),
            .init(name: "limit", value: "1"),
            .init(name: "hidebroken", value: "true"),
            .init(name: "order", value: "votes"),
            .init(name: "reverse", value: "true")
        ]
        guard let url = comps.url else {
            print("❌ Failed to construct URL")
            return nil
        }
        
        print("🔍 Searching for station: \(name)")
        print("📡 API URL: \(url.absoluteString)")
        
        do {
            let (data, response) = try await URLSession.shared.data(from: url)
            guard let http = response as? HTTPURLResponse else {
                print("❌ Invalid HTTP response")
                return nil
            }
            
            print("📊 Response status: \(http.statusCode)")
            
            guard http.statusCode == 200 else {
                print("❌ HTTP error: \(http.statusCode)")
                return nil
            }
            
            let stations = try JSONDecoder().decode([StationDTO].self, from: data)
            print("✅ Found \(stations.count) station(s)")
            
            guard let first = stations.first else {
                print("⚠️ No stations found for: \(name)")
                return nil
            }
            
            print("🎵 Station: \(first.name)")
            
            guard let urlStr = first.url_resolved, let stream = URL(string: urlStr) else {
                print("❌ Invalid stream URL")
                return nil
            }
            
            print("🎧 Stream URL: \(stream.absoluteString)")
            return stream
        } catch {
            print("❌ Error: \(error.localizedDescription)")
            return nil
        }
    }
}
