import Foundation

/// Test helper to verify Radio Browser API connectivity
/// Run this in your app to debug API issues
class RadioAPITest {
    
    static func testAPI() async {
        print("🧪 Testing Radio Browser API...")
        print("=" .repeating(50))
        
        let service = RadioBrowserService()
        
        // Test various station names
        let stationNames = [
            "Yes FM",
            "Love Radio",
            "Monster",
            "Wish 107.5",
            "Easy Rock",
            "DZRM"
        ]
        
        for station in stationNames {
            print("\n🔍 Testing: \(station)")
            if let url = await service.resolveFirstStation(named: station) {
                print("✅ SUCCESS - Stream URL: \(url.absoluteString)")
            } else {
                print("❌ FAILED - No stream found for \(station)")
            }
            
            // Add a small delay to avoid overwhelming the API
            try? await Task.sleep(nanoseconds: 500_000_000) // 0.5 seconds
        }
        
        print("\n" + "=".repeating(50))
        print("🧪 API Test Complete")
    }
}
