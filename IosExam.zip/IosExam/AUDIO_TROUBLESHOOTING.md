# Audio Troubleshooting Guide

## ✅ Changes Made to Fix Audio

1. **Added Player Status Monitoring** - The app now watches when the audio is ready to play
2. **Set Volume to 1.0** - Ensures player volume is at maximum (not muted)
3. **Audio Session Setup** - Configured at app startup for playback mode
4. **Better Error Reporting** - Shows specific errors if playback fails

## 🔍 How to Diagnose "No Sound" Issue

### Step 1: Check Physical Device Settings

**On iPhone/iPad:**
- ✅ Volume is turned UP (use volume buttons)
- ✅ Silent/Ring switch is OFF (no orange showing)
- ✅ Not using headphones (unless you want to)
- ✅ Bluetooth isn't routing audio elsewhere

### Step 2: Check Xcode Console

Run your app and click a radio station. Look for these logs:

**✅ GOOD - Audio should work:**
```
🔍 Searching for station: Yes FM
✅ Using fallback stream for Yes FM
🎧 Stream URL: http://radio.garden/api/ara/content/listen/EXwvy-Dl/channel.mp3
🔴 Starting playback for: Yes FM
✅ Attempting to play: Yes FM
🔊 Volume set to: 1.0
✅ Player ready to play
```

**❌ BAD - Audio won't work:**
```
❌ Player failed: The operation couldn't be completed
```

### Step 3: Check App UI

1. **Open the player sheet** (tap a station)
2. **Check the volume slider** - should not be at zero
3. **Look for error messages** - red text below station name
4. **Play button** - should show pause icon when playing

### Step 4: Test Different Stations

Some streams might be offline. Try multiple stations:
- Wish 107.5
- Love Radio
- Yes FM
- Monster FM

If ONE works, the others should too.

### Step 5: Simulator vs Real Device

**Simulator Issues:**
- Some radio streams don't work in iOS Simulator
- Audio drivers may not be properly configured
- Limited network streaming support

**Solution:** Test on a **REAL iPhone/iPad** for best results.

## 🔧 Advanced Troubleshooting

### Check Stream URLs Manually

Open Safari on your phone and try this URL:
```
http://radio.garden/api/ara/content/listen/EXwvy-Dl/channel.mp3
```

If you hear audio in Safari, the stream works - problem is in the app code.
If Safari also has no audio, the stream URL is dead.

### Check Internet Connection

- Radio needs **active internet connection**
- Try opening a website to confirm internet works
- Some WiFi networks block streaming (schools, offices)

### Check Background Audio Permission

In Xcode:
1. Select your project in Navigator
2. Go to **Signing & Capabilities**
3. Add **Background Modes** capability if not present
4. Enable **Audio, AirPlay, and Picture in Picture**

## 🎯 Most Common Solutions

### Solution 1: Volume is Zero
**Problem:** Device volume or app volume slider at 0
**Fix:** Turn up volume on device, check slider in app

### Solution 2: Silent Mode ON
**Problem:** iPhone silent switch is enabled
**Fix:** Toggle the switch on the left side of iPhone (no orange should show)

### Solution 3: Testing on Simulator
**Problem:** iOS Simulator has limited audio streaming
**Fix:** Test on a real iPhone/iPad

### Solution 4: Stream URL is Dead
**Problem:** The radio station's stream is offline
**Fix:** Try a different station

### Solution 5: Background Audio Not Configured
**Problem:** App doesn't have audio background capability
**Fix:** Add Background Modes in Xcode project settings

## 📱 Quick Test Procedure

1. **Use a REAL iPhone** (not simulator)
2. **Turn volume UP** to maximum
3. **Turn silent mode OFF**
4. **Open your app**
5. **Tap "Yes FM"** station
6. **Wait 2-3 seconds** for buffering
7. **Should hear audio!** 🎵

## 🆘 Still No Sound?

If you've tried everything:

1. **Share Console Logs** - Copy the logs from Xcode console when you click a station
2. **Check Xcode Project Settings:**
   - Target → Signing & Capabilities
   - Make sure Background Modes includes Audio

3. **Restart Everything:**
   - Close Xcode
   - Restart your iPhone
   - Rebuild and run the app

4. **Try Alternative Stream URLs:**
   Some stations might have better streams. You can update the fallback URLs in `RadioService.swift`.

---

## Expected Behavior

✅ Click station → See loading spinner → Hear audio within 2-3 seconds
✅ Play button becomes pause button
✅ "Now Playing" shows station name
✅ Volume slider controls audio level

If this happens, everything is working correctly! 🎉
