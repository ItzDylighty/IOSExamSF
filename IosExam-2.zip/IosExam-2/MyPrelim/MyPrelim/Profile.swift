import SwiftUI
import SwiftData
import PhotosUI

struct ProfileView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.modelContext) private var context
    @Query private var users: [User]

    @State private var username: String = ""
    @State private var email: String = ""
    @State private var profileImageData: Data? = nil
    @State private var isAccountListExpanded: Bool = false
    @State private var removedAccounts: Set<String> = []

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 28) {

                    // User Info with Edit Button
                    HStack(spacing: 16) {
                        if let data = profileImageData,
                           let uiImage = UIImage(data: data) {
                            Image(uiImage: uiImage)
                                .resizable()
                                .frame(width: 60, height: 60)
                                .clipShape(Circle())
                        } else {
                            Image(systemName: "person.circle.fill")
                                .resizable()
                                .frame(width: 60, height: 60)
                                .foregroundColor(.gray)
                                .clipShape(Circle())
                        }

                        VStack(alignment: .leading, spacing: 4) {
                            Text(username.isEmpty ? "Guest" : username)
                                .font(.headline)
                            Text(email.isEmpty ? "Email not set" : email)
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                        
                        Spacer()
                        
                        NavigationLink(destination: EditProfileView(username: $username,
                                                                   email: $email,
                                                                   profileImageData: $profileImageData)) {
                            Text("Edit")
                                .font(.subheadline)
                                .fontWeight(.semibold)
                                .foregroundColor(.blue)
                        }
                    }
                    .padding(.horizontal)
                    .padding(.vertical, 16)
                    .background(Color(.systemGray6).opacity(0.5))
                    .cornerRadius(12)
                    .padding(.horizontal)
                    .padding(.top, 20)

                    Divider()

                    VStack(spacing: 0) {
                        Button(action: {
                            withAnimation {
                                isAccountListExpanded.toggle()
                            }
                        }) {
                            HStack {
                                Text("Switch Account")
                                    .foregroundColor(.primary)
                                Spacer()
                                Image(systemName: isAccountListExpanded ? "chevron.up" : "chevron.down")
                                    .foregroundColor(.gray)
                            }
                            .padding(.horizontal)
                            .padding(.vertical, 8)
                        }
                        
                        if isAccountListExpanded {
                            VStack(spacing: 0) {
                                ForEach(users.filter { $0.username != username && !removedAccounts.contains($0.username) }, id: \.username) { user in
                                    HStack(spacing: 0) {
                                        Button(action: {
                                            switchToAccount(user)
                                        }) {
                                            HStack(spacing: 12) {
                                                if let data = user.profileImage,
                                                   let uiImage = UIImage(data: data) {
                                                    Image(uiImage: uiImage)
                                                        .resizable()
                                                        .frame(width: 40, height: 40)
                                                        .clipShape(Circle())
                                                } else {
                                                    Image(systemName: "person.circle.fill")
                                                        .resizable()
                                                        .frame(width: 40, height: 40)
                                                        .foregroundColor(.gray)
                                                }
                                                
                                                VStack(alignment: .leading, spacing: 2) {
                                                    Text(user.username)
                                                        .font(.subheadline)
                                                        .foregroundColor(.primary)
                                                    if let userEmail = user.email, !userEmail.isEmpty {
                                                        Text(userEmail)
                                                            .font(.caption)
                                                            .foregroundColor(.gray)
                                                    }
                                                }
                                                
                                                Spacer()
                                            }
                                            .padding(.leading)
                                            .padding(.vertical, 12)
                                        }
                                        
                                        Button(action: {
                                            removeAccount(user)
                                        }) {
                                            Image(systemName: "minus.circle.fill")
                                                .foregroundColor(.red)
                                                .frame(width: 44, height: 44)
                                        }
                                        .padding(.trailing)
                                    }
                                    .background(Color(.systemGray6).opacity(0.5))
                                    
                                    if user.username != users.filter({ $0.username != username && !removedAccounts.contains($0.username) }).last?.username {
                                        Divider()
                                            .padding(.leading, 64)
                                    }
                                }
                                
                                // Add Account button
                                Button(action: {
                                    // Log out to show login/signup screen
                                    let player = RadioPlayer.shared
                                    player.pause()
                                    player.currentStationName = nil
                                    player.currentStationImage = nil
                                    appState.isLoggedIn = false
                                }) {
                                    HStack(spacing: 12) {
                                        Image(systemName: "plus.circle.fill")
                                            .resizable()
                                            .frame(width: 40, height: 40)
                                            .foregroundColor(.blue)
                                        
                                        Text("Add Account")
                                            .font(.subheadline)
                                            .foregroundColor(.primary)
                                        
                                        Spacer()
                                    }
                                    .padding(.horizontal)
                                    .padding(.vertical, 12)
                                }
                                .background(Color(.systemGray6).opacity(0.5))
                            }
                            .transition(.opacity)
                        }
                    }

                    Divider()

                    // Dark Mode Toggle
                    HStack {
                        Text("Dark Mode")
                            .foregroundColor(.primary)
                        Spacer()
                        Toggle("", isOn: Binding(
                            get: { appState.isDarkMode },
                            set: { newValue in
                                appState.isDarkMode = newValue
                            }
                        ))
                        .labelsHidden()
                    }
                    .padding(.horizontal)
                    .padding(.vertical, 8)

                    Divider()

                    VStack(alignment: .leading, spacing: 20) {
                        Text("Support")
                            .font(.headline)
                        HStack {
                            Text("App feedback")
                            Spacer()
                            Image(systemName: "arrow.up.right")
                                .foregroundColor(.gray)
                        }
                        HStack {
                            Text("Help centre")
                            Spacer()
                            Image(systemName: "arrow.up.right")
                                .foregroundColor(.gray)
                        }
                    }
                    .padding(.horizontal)

                    Divider()

                    VStack(alignment: .leading, spacing: 20) {
                        Text("Preferences")
                            .font(.headline)
                        HStack {
                            Text("Language")
                            Spacer()
                            Text("English")
                                .foregroundColor(.gray)
                            Image(systemName: "chevron.right")
                                .foregroundColor(.gray)
                        }
                        HStack {
                            Text("Notification")
                            Spacer()
                            Image(systemName: "chevron.right")
                                .foregroundColor(.gray)
                        }
                    }
                    .padding(.horizontal)

                    Spacer(minLength: 30)

                    Button(action: {
                        let player = RadioPlayer.shared
                        player.pause()
                        // Reset player state on logout
                        player.currentStationName = nil
                        player.currentStationImage = nil
                        appState.isLoggedIn = false
                    }) {
                        Text("Log out")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.primary)
                            .foregroundColor(Color(UIColor.systemBackground))
                            .cornerRadius(25)
                            .padding(.horizontal)
                    }
                    .padding(.bottom, 150)
                }
            }
            .onAppear {
                loadCurrentUser()
            }
        }
    }
    
    private func loadCurrentUser() {
        if let current = UserDefaults.standard.string(forKey: "currentUsername"),
           let user = users.first(where: { $0.username == current }) {
            username = user.username
            email = user.email ?? ""
            profileImageData = user.profileImage
        }
    }
    
    private func switchToAccount(_ user: User) {
        // Update UserDefaults with the new current user
        UserDefaults.standard.set(user.username, forKey: "currentUsername")
        
        // Update the displayed user info
        username = user.username
        email = user.email ?? ""
        profileImageData = user.profileImage
        
        // Collapse the account list
        withAnimation {
            isAccountListExpanded = false
        }
        
        // Optionally reset the radio player when switching accounts
        let player = RadioPlayer.shared
        player.pause()
        player.currentStationName = nil
        player.currentStationImage = nil
    }
    
    private func removeAccount(_ user: User) {
        withAnimation {
            removedAccounts.insert(user.username)
        }
    }
}

struct EditProfileView: View {
    @Binding var username: String
    @Binding var email: String
    @Binding var profileImageData: Data?

    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context
    @Query private var users: [User]

    @State private var newUsername: String = ""
    @State private var newPassword: String = ""
    @State private var newEmail: String = ""
    @State private var selectedItem: PhotosPickerItem? = nil

    var body: some View {
        VStack(spacing: 20) {
            HStack {
                Text("Edit Profile")
                    .font(.largeTitle)
                    .bold()
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)

            PhotosPicker(selection: $selectedItem, matching: .images, photoLibrary: .shared()) {
                if let data = profileImageData,
                   let uiImage = UIImage(data: data) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .frame(width: 100, height: 100)
                        .clipShape(Circle())
                        .overlay(
                            Circle()
                                .stroke(Color.gray.opacity(0.5), lineWidth: 2)
                        )
                } else {
                    Image(systemName: "person.circle.fill")
                        .resizable()
                        .frame(width: 100, height: 100)
                        .foregroundColor(.gray)
                        .clipShape(Circle())
                }
            }
            .onChange(of: selectedItem) { newValue in
                guard let newValue else { return }
                Task {
                    if let data = try? await newValue.loadTransferable(type: Data.self) {
                        profileImageData = data
                        
                        // Save image to database immediately
                        if let currentUsername = UserDefaults.standard.string(forKey: "currentUsername"),
                           let user = users.first(where: { $0.username == currentUsername }) {
                            user.profileImage = data
                            try? context.save()
                        }
                    }
                }
            }
            
            Text("Tap image to change")
                .font(.caption)
                .foregroundColor(.gray)
                .padding(.bottom, 10)

            TextField("Username", text: $newUsername)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding(.horizontal)

            SecureField("Password", text: $newPassword)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding(.horizontal)

            TextField("Email", text: $newEmail)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding(.horizontal)

            Button(action: {
                guard let currentUsername = UserDefaults.standard.string(forKey: "currentUsername"),
                      let user = users.first(where: { $0.username == currentUsername }) else { return }

                if !newUsername.isEmpty { user.username = newUsername }
                if !newPassword.isEmpty { user.password = newPassword }
                if !newEmail.isEmpty { user.email = newEmail }
                if let img = profileImageData {
                    user.profileImage = img
                }

                try? context.save()

                username = user.username
                email = user.email ?? ""
                UserDefaults.standard.set(user.username, forKey: "currentUsername")

                dismiss()
            }) {
                Text("Save Changes")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.primary)
                    .foregroundColor(Color(UIColor.systemBackground))
                    .cornerRadius(25)
                    .padding(.horizontal)
            }

            Button(action: { dismiss() }) {
                Text("Cancel")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.gray.opacity(0.3))
                    .foregroundColor(.primary)
                    .cornerRadius(25)
                    .padding(.horizontal)
            }

            Spacer()
        }
        .onAppear {
            newUsername = username
            newEmail = email
        }
    }
}
