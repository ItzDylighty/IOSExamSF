import SwiftUI
import SwiftData

struct Station: Identifiable {
    let id = UUID()
    let name: String
    let image: String
}

struct SearchView: View {
    @State private var searchText = ""
    @Query private var users: [User]
    @State private var profileImageData: Data? = nil
    @State private var recentSearches: [String] = []
    @State private var shuffledStations: [Station] = []

    let stations = [
        Station(name: "DZRM 612", image: "Dzrm"),
        Station(name: "Monster FM", image: "Monster"),
        Station(name: "Yes FM", image: "Yes"),
        Station(name: "Veritas", image: "Veritas"),
        Station(name: "Wish 107.5", image: "Wish"),
        Station(name: "Easy Rock", image: "Easyrock"),
        Station(name: "Love Radio", image: "Love"),
        Station(name: "Radyo 5", image: "Radyo5"),
        Station(name: "Barangay LS 97.1", image: "Barangay"),
        Station(name: "Home Radio", image: "Home"),
        Station(name: "Energy FM", image: "Energy"),
        Station(name: "Brigada News FM", image: "Brigada"),
        Station(name: "Radyo Natin", image: "RadyoNatin")
    ]

    var filteredStations: [Station] {
        if searchText.isEmpty {
            return stations
        } else {
            return stations.filter { $0.name.lowercased().contains(searchText.lowercased()) }
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            // Fixed Header
            HStack {
                Text("Search")
                    .font(.system(size: 28, weight: .bold))

                Spacer()

                // Show saved profile photo if available, else default icon
                if let data = profileImageData,
                   let uiImage = UIImage(data: data) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .frame(width: 28, height: 28)
                        .clipShape(Circle())
                } else {
                    Image(systemName: "person.circle")
                        .resizable()
                        .frame(width: 28, height: 28)
                }
            }
            .padding(.horizontal)
            .padding(.top, 10)

            // Search Bar
            HStack {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.gray)
                TextField("Search", text: $searchText)
                    .onSubmit {
                        if !searchText.isEmpty && !filteredStations.isEmpty {
                            addToRecentSearches(searchText)
                        }
                    }
                
                if !searchText.isEmpty {
                    Button(action: {
                        searchText = ""
                    }) {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.gray)
                    }
                }
            }
            .padding()
            .background(Color(.systemGray6))
            .cornerRadius(10)
            .padding(.horizontal)

            // Main Scroll Area
            ScrollView(.vertical, showsIndicators: true) {
                VStack(alignment: .leading, spacing: 20) {
                    
                    // Recent Searches (show when search is empty)
                    if searchText.isEmpty && !recentSearches.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            HStack {
                                Text("Recent Searches")
                                    .font(.headline)
                                    .padding(.horizontal)
                                Spacer()
                                Button(action: {
                                    recentSearches.removeAll()
                                    saveRecentSearches()
                                }) {
                                    Text("Clear")
                                        .font(.subheadline)
                                        .foregroundColor(.blue)
                                        .padding(.horizontal)
                                }
                            }
                            
                            ForEach(recentSearches, id: \.self) { search in
                                Button(action: {
                                    searchText = search
                                }) {
                                    HStack {
                                        Image(systemName: "clock.arrow.circlepath")
                                            .foregroundColor(.gray)
                                        Text(search)
                                            .foregroundColor(.primary)
                                        Spacer()
                                        Image(systemName: "arrow.up.left")
                                            .foregroundColor(.gray)
                                            .font(.caption)
                                    }
                                    .padding(.horizontal)
                                    .padding(.vertical, 8)
                                }
                            }
                        }
                        .padding(.bottom, 10)
                    }

                    if filteredStations.isEmpty {
                        Text("Station Not Found")
                            .font(.headline)
                            .foregroundColor(.gray)
                            .frame(maxWidth: .infinity, minHeight: 200, alignment: .center)
                    } else {
                        // Only show Featured Stations section when NOT searching
                        if searchText.isEmpty {
                            // Featured Stations
                            Text("Featured Stations")
                                .font(.headline)
                                .padding(.horizontal)

                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 16) {
                                    ForEach(shuffledStations) { station in
                                        VStack {
                                            Image(station.image)
                                                .resizable()
                                                .aspectRatio(contentMode: .fill)
                                                .frame(width: 120, height: 120)
                                                .cornerRadius(12)

                                            Text(station.name)
                                                .font(.caption)
                                                .foregroundColor(.primary)
                                        }
                                        .onTapGesture {
                                            Task { await RadioPlayer.shared.play(stationName: station.name, imageName: station.image) }
                                            NotificationCenter.default.post(name: .openPlayerSheet, object: nil)
                                        }
                                    }
                                }
                                .padding(.horizontal)
                            }

                            // All Stations header (only when not searching)
                            Text("All Stations")
                                .font(.headline)
                                .padding(.horizontal)
                        }

                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
                            ForEach(filteredStations) { station in
                                VStack {
                                    Image(station.image)
                                        .resizable()
                                        .aspectRatio(contentMode: .fill)
                                        .frame(width: 150, height: 150)
                                        .cornerRadius(8)

                                    Text(station.name)
                                        .font(.caption)
                                        .foregroundColor(.primary)
                                }
                                .onTapGesture {
                                    Task { await RadioPlayer.shared.play(stationName: station.name, imageName: station.image) }
                                    NotificationCenter.default.post(name: .openPlayerSheet, object: nil)
                                }
                            }
                        }
                        .padding(.horizontal)
                        .padding(.bottom, 100)
                    }
                }
                .padding(.vertical)
            }

            Spacer()
        }
        .onAppear {
            if let currentUsername = UserDefaults.standard.string(forKey: "currentUsername"),
               let user = users.first(where: { $0.username == currentUsername }) {
                profileImageData = user.profileImage
            } else {
                profileImageData = nil
            }
            loadRecentSearches()
            shuffleFeaturedStations()
        }
    }
    
    private func addToRecentSearches(_ search: String) {
        // Remove if already exists
        recentSearches.removeAll { $0 == search }
        
        // Add to beginning
        recentSearches.insert(search, at: 0)
        
        // Keep only last 10 searches
        if recentSearches.count > 10 {
            recentSearches = Array(recentSearches.prefix(10))
        }
        
        saveRecentSearches()
    }
    
    private func saveRecentSearches() {
        UserDefaults.standard.set(recentSearches, forKey: "recentSearches")
    }
    
    private func loadRecentSearches() {
        if let saved = UserDefaults.standard.array(forKey: "recentSearches") as? [String] {
            recentSearches = saved
        }
    }
    
    private func shuffleFeaturedStations() {
        shuffledStations = stations.shuffled()
    }
}

#Preview {
    SearchView()
}
