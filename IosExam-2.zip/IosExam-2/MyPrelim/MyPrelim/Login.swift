import SwiftUI
import SwiftData

struct LoginView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.modelContext) private var context
    @Query private var users: [User]

    @State private var username: String = ""
    @State private var password: String = ""
    @State private var isShowingSignup = false
    @State private var showLoginSuccessAlert = false
    @State private var showLoginErrorAlert = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                VStack(spacing: 4) {
                    Image(systemName: "radio.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 70, height: 70)
                        .foregroundColor(.primary)
                }
                .padding(.top, 50)

                VStack(spacing: 4) {
                    Text("Log in to your account")
                        .font(.headline)
                    Text("Enter your email to sign in for this app")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
                .multilineTextAlignment(.center)
                .padding(.top, 8)

                VStack(spacing: 12) {
                    TextField("Username", text: $username)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(10)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()

                    SecureField("Password", text: $password)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(10)
                }
                .padding(.top, 12)

                Button(action: loginUser) {
                    Text("Log in")
                        .foregroundColor(Color(UIColor.systemBackground))
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.primary)
                        .cornerRadius(10)
                }
                .padding(.top, 8)

                HStack(spacing: 4) {
                    Text("Don’t have an account?")
                        .foregroundColor(.gray)
                    Button(action: { isShowingSignup = true }) {
                        Text("Create Here")
                            .foregroundColor(.blue)
                    }
                }
                .font(.footnote)
                .padding(.top, 6)

                HStack {
                    Rectangle()
                        .frame(height: 1)
                        .foregroundColor(.gray.opacity(0.4))
                    Text("or")
                        .foregroundColor(.gray)
                    Rectangle()
                        .frame(height: 1)
                        .foregroundColor(.gray.opacity(0.4))
                }
                .padding(.vertical, 12)

                Button(action: { print("Google tapped") }) {
                    HStack {
                        Image(systemName: "globe")
                        Text("Continue with Google")
                    }
                    .foregroundColor(.primary)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color(.systemGray5))
                    .cornerRadius(10)
                }

                Button(action: { print("Apple tapped") }) {
                    HStack {
                        Image(systemName: "applelogo")
                        Text("Continue with Apple")
                    }
                    .foregroundColor(.primary)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color(.systemGray5))
                    .cornerRadius(10)
                }

                Spacer()

                Text("By clicking continue, you agree to our Terms of Service and Privacy Policy")
                    .font(.footnote)
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 20)
                    .padding(.bottom, 45)
            }
            .padding(.horizontal, 20)
            .ignoresSafeArea(edges: .bottom)
            .navigationDestination(isPresented: $isShowingSignup) {
                SignupView()
            }
            .alert("Login Successful", isPresented: $showLoginSuccessAlert) {
                Button("OK") { }
            } message: {
                Text("You have logged in successfully!")
            }
            .alert("Login Failed", isPresented: $showLoginErrorAlert) {
                Button("OK") { }
            } message: {
                Text("Invalid username or password.")
            }
        }
    }

    private func loginUser() {
        // check against SwiftData users
        if let user = users.first(where: { $0.username == username && $0.password == password }) {
            // remember which user is logged in
            UserDefaults.standard.set(user.username, forKey: "currentUsername")
            appState.isLoggedIn = true
            showLoginSuccessAlert = true
        } else {
            showLoginErrorAlert = true
        }
    }
}

struct SignupView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context
    @Query private var users: [User]

    @State private var username: String = ""
    @State private var password: String = ""
    @State private var reEnterPassword: String = ""
    @State private var showPasswordMismatchAlert = false
    @State private var showUserExistsAlert = false

    var body: some View {
        VStack(spacing: 16) {
            Text("Create your account")
                .font(.largeTitle)
                .bold()
                .padding(.top, 50)

            VStack(spacing: 12) {
                TextField("Username", text: $username)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)
                    .textInputAutocapitalization(.never)

                SecureField("Password", text: $password)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)

                SecureField("Re-Enter Password", text: $reEnterPassword)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)
            }
            .padding(.top, 20)

            Button(action: createAccount) {
                Text("Create")
                    .foregroundColor(Color(UIColor.systemBackground))
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.primary)
                    .cornerRadius(10)
            }
            .padding(.top, 12)
            .alert("Passwords do not match", isPresented: $showPasswordMismatchAlert) {
                Button("OK", role: .cancel) { }
            }
            .alert("Username already exists", isPresented: $showUserExistsAlert) {
                Button("OK", role: .cancel) { }
            }

            Spacer()
        }
        .padding(.horizontal, 20)
        .navigationBarItems(leading: Button(action: {
            dismiss()
        }) {
            HStack {
                Image(systemName: "chevron.left")
                    .foregroundColor(.primary)
                Text("Back")
                    .foregroundColor(.primary)
            }
        })
        .navigationBarBackButtonHidden(true) // Hides the default back button
    }

    private func createAccount() {
        guard password == reEnterPassword, !password.isEmpty else {
            showPasswordMismatchAlert = true
            return
        }
        // prevent duplicate usernames
        if users.contains(where: { $0.username == username }) {
            showUserExistsAlert = true
            return
        }

        let newUser = User(username: username, password: password)
        context.insert(newUser)
        try? context.save()
        dismiss()
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView().environmentObject(AppState())
    }
}

