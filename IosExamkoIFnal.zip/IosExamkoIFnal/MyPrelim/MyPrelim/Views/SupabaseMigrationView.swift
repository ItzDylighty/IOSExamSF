import SwiftUI

/// View for managing Supabase migration and sync
struct SupabaseMigrationView: View {
    @State private var users: [User] = []
    @StateObject private var migrationStatus = MigrationStatus()
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                // Header
                VStack(spacing: 8) {
                    Image(systemName: "cloud.arrow.up.fill")
                        .font(.system(size: 40))
                        .foregroundColor(.blue)
                    
                    Text("Migrate to Supabase")
                        .font(.title2)
                        .bold()
                    
                    Text("Transfer your data to the cloud")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
                .padding(.vertical, 20)
                
                // Status Section
                VStack(spacing: 12) {
                    HStack {
                        Text("Users to migrate:")
                            .font(.subheadline)
                        Spacer()
                        Text("\(users.count)")
                            .font(.subheadline)
                            .fontWeight(.semibold)
                    }
                    
                    if migrationStatus.isRunning {
                        VStack(spacing: 8) {
                            ProgressView(value: migrationStatus.progress)
                                .tint(.blue)
                            
                            HStack {
                                Text("Migrating: \(migrationStatus.currentUser)")
                                    .font(.caption)
                                    .foregroundColor(.gray)
                                Spacer()
                                Text("\(migrationStatus.completedUsers)/\(migrationStatus.totalUsers)")
                                    .font(.caption)
                                    .fontWeight(.semibold)
                            }
                        }
                    }
                }
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(12)
                
                // Messages
                if let error = migrationStatus.errorMessage {
                    HStack(spacing: 12) {
                        Image(systemName: "exclamationmark.circle.fill")
                            .foregroundColor(.red)
                        Text(error)
                            .font(.caption)
                            .foregroundColor(.red)
                        Spacer()
                    }
                    .padding()
                    .background(Color.red.opacity(0.1))
                    .cornerRadius(8)
                }
                
                if let success = migrationStatus.successMessage {
                    HStack(spacing: 12) {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(.green)
                        Text(success)
                            .font(.caption)
                            .foregroundColor(.green)
                        Spacer()
                    }
                    .padding()
                    .background(Color.green.opacity(0.1))
                    .cornerRadius(8)
                }
                
                // Instructions
                VStack(alignment: .leading, spacing: 12) {
                    Text("Before you start:")
                        .font(.subheadline)
                        .fontWeight(.semibold)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        HStack(spacing: 8) {
                            Text("1.")
                                .fontWeight(.semibold)
                            Text("Configure Supabase credentials in SupabaseConfig.swift")
                                .font(.caption)
                        }
                        
                        HStack(spacing: 8) {
                            Text("2.")
                                .fontWeight(.semibold)
                            Text("Create the users table in Supabase")
                                .font(.caption)
                        }
                        
                        HStack(spacing: 8) {
                            Text("3.")
                                .fontWeight(.semibold)
                            Text("Ensure internet connection is active")
                                .font(.caption)
                        }
                    }
                    .foregroundColor(.gray)
                }
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(12)
                
                Spacer()
                
                // Action Buttons
                VStack(spacing: 12) {
                    Button(action: startMigration) {
                        HStack {
                            Image(systemName: "arrow.up.to.line")
                            Text(migrationStatus.isRunning ? "Migrating..." : "Start Migration")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .fontWeight(.semibold)
                    }
                    .disabled(migrationStatus.isRunning || users.isEmpty)
                    
                    Button(action: { dismiss() }) {
                        Text("Cancel")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color(.systemGray5))
                            .foregroundColor(.primary)
                            .cornerRadius(10)
                    }
                    .disabled(migrationStatus.isRunning)
                }
                
                if users.isEmpty {
                    Text("No users to migrate")
                        .font(.caption)
                        .foregroundColor(.gray)
                }
            }
            .padding()
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: { dismiss() }) {
                        HStack {
                            Image(systemName: "chevron.left")
                            Text("Back")
                        }
                        .foregroundColor(.blue)
                    }
                    .disabled(migrationStatus.isRunning)
                }
            }
        }
    }
    
    private func startMigration() {
        Task {
            migrationStatus.isRunning = true
            migrationStatus.reset()
            migrationStatus.totalUsers = users.count
            
            do {
                let migration = DataMigration()
                let migratedUsers = try await migration.migrateUsersToSupabase(
                    users: users,
                    progressHandler: { completed, total in
                        DispatchQueue.main.async {
                            migrationStatus.updateProgress(completed: completed, total: total)
                            if completed < total {
                                migrationStatus.currentUser = users[completed].username
                            }
                        }
                    }
                )
                
                DispatchQueue.main.async {
                    migrationStatus.successMessage = "✓ Successfully migrated \(migratedUsers.count) user(s) to Supabase!"
                    migrationStatus.isRunning = false
                }
            } catch {
                DispatchQueue.main.async {
                    migrationStatus.errorMessage = error.localizedDescription
                    migrationStatus.isRunning = false
                }
            }
        }
    }
}

#Preview {
    SupabaseMigrationView()
}
