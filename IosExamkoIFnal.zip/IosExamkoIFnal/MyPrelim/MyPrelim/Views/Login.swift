import SwiftUI

struct LoginView: View {
    @EnvironmentObject var appState: AppState

    @State private var username: String = ""
    @State private var password: String = ""
    @State private var isShowingSignup = false
    @State private var showLoginSuccessAlert = false
    @State private var showLoginErrorAlert = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                VStack(spacing: 4) {
                    Image(systemName: "radio.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 70, height: 70)
                        .foregroundColor(.primary)
                }
                .padding(.top, 50)

                VStack(spacing: 4) {
                    Text("Log in to your account")
                        .font(.headline)
                    Text("Enter your email to sign in for this app")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
                .multilineTextAlignment(.center)
                .padding(.top, 8)

                VStack(spacing: 12) {
                    TextField("Username", text: $username)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(10)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()

                    SecureField("Password", text: $password)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(10)
                }
                .padding(.top, 12)

                Button(action: loginUser) {
                    Text("Log in")
                        .foregroundColor(Color(UIColor.systemBackground))
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.primary)
                        .cornerRadius(10)
                }
                .padding(.top, 8)

                HStack(spacing: 4) {
                    Text("Don’t have an account?")
                        .foregroundColor(.gray)
                    Button(action: { isShowingSignup = true }) {
                        Text("Create Here")
                            .foregroundColor(.blue)
                    }
                }
                .font(.footnote)
                .padding(.top, 6)

                HStack {
                    Rectangle()
                        .frame(height: 1)
                        .foregroundColor(.gray.opacity(0.4))
                    Text("or")
                        .foregroundColor(.gray)
                    Rectangle()
                        .frame(height: 1)
                        .foregroundColor(.gray.opacity(0.4))
                }
                .padding(.vertical, 12)

                Button(action: { print("Google tapped") }) {
                    HStack {
                        Image(systemName: "globe")
                        Text("Continue with Google")
                    }
                    .foregroundColor(.primary)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color(.systemGray5))
                    .cornerRadius(10)
                }

                Button(action: { print("Apple tapped") }) {
                    HStack {
                        Image(systemName: "applelogo")
                        Text("Continue with Apple")
                    }
                    .foregroundColor(.primary)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color(.systemGray5))
                    .cornerRadius(10)
                }

                Spacer()

                Text("By clicking continue, you agree to our Terms of Service and Privacy Policy")
                    .font(.footnote)
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 20)
                    .padding(.bottom, 45)
            }
            .padding(.horizontal, 20)
            .ignoresSafeArea(edges: .bottom)
            .navigationDestination(isPresented: $isShowingSignup) {
                SignupView()
            }
            .alert("Login Successful", isPresented: $showLoginSuccessAlert) {
                Button("OK") { }
            } message: {
                Text("You have logged in successfully!")
            }
            .alert("Login Failed", isPresented: $showLoginErrorAlert) {
                Button("OK") { }
            } message: {
                Text("Invalid username or password.")
            }
        }
    }

    private func loginUser() {
        Task {
            do {
                // Check against Supabase first
                let supabaseUsers = try await SupabaseService.shared.fetchUsers()
                
                if let user = supabaseUsers.first(where: { 
                    $0.username == username && $0.password == password 
                }) {
                    // Remember which user is logged in
                    UserDefaults.standard.set(user.username, forKey: "currentUsername")
                    
                    // Add to saved accounts list
                    var savedAccountUsernames = UserDefaults.standard.stringArray(forKey: "savedAccountUsernames") ?? []
                    if !savedAccountUsernames.contains(user.username) {
                        savedAccountUsernames.append(user.username)
                        UserDefaults.standard.set(savedAccountUsernames, forKey: "savedAccountUsernames")
                    }
                    
                    DispatchQueue.main.async {
                        appState.isLoggedIn = true
                        showLoginSuccessAlert = true
                    }
                } else {
                    DispatchQueue.main.async {
                        showLoginErrorAlert = true
                    }
                }
            } catch {
                print("Login error: \(error)")
                DispatchQueue.main.async {
                    showLoginErrorAlert = true
                }
            }
        }
    }
}

struct SignupView: View {
    @Environment(\.dismiss) private var dismiss

    @State private var username: String = ""
    @State private var password: String = ""
    @State private var reEnterPassword: String = ""
    @State private var showPasswordMismatchAlert = false
    @State private var showUserExistsAlert = false

    var body: some View {
        VStack(spacing: 16) {
            Text("Create your account")
                .font(.largeTitle)
                .bold()
                .padding(.top, 50)

            VStack(spacing: 12) {
                TextField("Username", text: $username)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)
                    .textInputAutocapitalization(.never)

                SecureField("Password", text: $password)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)

                SecureField("Re-Enter Password", text: $reEnterPassword)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(10)
            }
            .padding(.top, 20)

            Button(action: createAccount) {
                Text("Create")
                    .foregroundColor(Color(UIColor.systemBackground))
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.primary)
                    .cornerRadius(10)
            }
            .padding(.top, 12)
            .alert("Passwords do not match", isPresented: $showPasswordMismatchAlert) {
                Button("OK", role: .cancel) { }
            }
            .alert("Username already exists", isPresented: $showUserExistsAlert) {
                Button("OK", role: .cancel) { }
            }

            Spacer()
        }
        .padding(.horizontal, 20)
        .navigationBarItems(leading: Button(action: {
            dismiss()
        }) {
            HStack {
                Image(systemName: "chevron.left")
                    .foregroundColor(.primary)
                Text("Back")
                    .foregroundColor(.primary)
            }
        })
        .navigationBarBackButtonHidden(true) // Hides the default back button
    }

    private func createAccount() {
        guard password == reEnterPassword, !password.isEmpty else {
            showPasswordMismatchAlert = true
            return
        }

        Task {
            do {
                print("Creating account for username: \(username)")
                
                // Check if username already exists in Supabase
                let existingUsers = try await SupabaseService.shared.fetchUsers()
                if existingUsers.contains(where: { $0.username == username }) {
                    DispatchQueue.main.async {
                        showUserExistsAlert = true
                    }
                    return
                }
                
                // Create user in Supabase
                let supabaseUser = SupabaseUser(
                    username: username,
                    password: password
                )
                print("Sending to Supabase...")
                let createdUser = try await SupabaseService.shared.createUser(supabaseUser)
                print("Supabase user created: \(createdUser)")
                
                DispatchQueue.main.async {
                    print("Dismissing signup view")
                    dismiss()
                }
            } catch {
                print("Error creating account: \(error)")
                print("Error details: \(error.localizedDescription)")
                if let supabaseError = error as? SupabaseError {
                    print("Supabase error: \(supabaseError.errorDescription ?? "Unknown")")
                }
            }
        }
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView().environmentObject(AppState())
    }
}

