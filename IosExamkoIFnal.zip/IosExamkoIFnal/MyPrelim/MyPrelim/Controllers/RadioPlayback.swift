import Foundation
import AVFoundation
import Combine

@MainActor
final class RadioPlayer: ObservableObject {
    static let shared = RadioPlayer()
    @Published var isPlaying: Bool = false
    @Published var currentStationName: String? = nil
    @Published var currentStationImage: String? = nil
    @Published var isLoading: Bool = false
    @Published var errorMessage: String? = nil
    @Published var isBuffering: Bool = false
    @Published var connectionStatus: String = "Idle"
    @Published var recentlyPlayed: [(name: String, image: String)] = []

    private var player: AVPlayer? = nil
    private var playerItem: AVPlayerItem? = nil
    private var statusObserver: NSKeyValueObservation? = nil
    private var timeObserver: Any? = nil
    private let service = RadioBrowserService()
    
    // Station list for next/previous navigation
    private let stationList: [(name: String, image: String)] = [
        ("Wish 107.5", "Wish"),
        ("Love Radio", "Love"),
        ("Monster", "Monster"),
        ("Yes FM", "Yes"),
        ("Easy Rock", "Easyrock"),
        ("DZRM", "Dzrm"),
        ("Veritas", "Veritas"),
        ("Barangay LS 97.1", "Barangay"),
        ("Home Radio", "Home"),
        ("Energy FM", "Energy"),
        ("Brigada News FM", "Brigada")
    ]
    
    private var currentStationIndex: Int = 0
    
    init() {
        setupAudioSession()
        loadRecentlyPlayed()
    }
    
    private func setupAudioSession() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [])
            try AVAudioSession.sharedInstance().setActive(true)
            print("Audio session configured")
        } catch {
            print("Audio session setup failed: \(error)")
        }
    }

    func play(stationName: String, imageName: String) async {
        print("\n" + String(repeating: "=", count: 50))
        print("PLAY REQUEST: \(stationName)")
        if let current = currentStationName, current != stationName {
            print("Switching from '\(current)' to '\(stationName)'")
        }
        print(String(repeating: "=", count: 50))
        
        // Clear any previous errors
        errorMessage = nil
        isLoading = true
        
        currentStationName = stationName
        currentStationImage = imageName
        
        // Add to recently played
        addToRecentlyPlayed(name: stationName, image: imageName)
        
        // Update current index
        if let index = stationList.firstIndex(where: { $0.name == stationName }) {
            currentStationIndex = index
        }
        
        print("Starting playback for: \(stationName)")
        
        let url = await service.resolveFirstStation(named: stationName)
        
        isLoading = false
        
        guard let url = url else {
            errorMessage = "Failed to find station '\(stationName)'. Please try another station."
            print("Failed to resolve station URL")
            pause()
            return
        }
        
        // Stop any existing playback
        player?.pause()
        statusObserver?.invalidate()
        if let observer = timeObserver {
            player?.removeTimeObserver(observer)
            timeObserver = nil
        }
        
        // Create new player item and player
        let item = AVPlayerItem(url: url)
        playerItem = item
        player = AVPlayer(playerItem: item)
        
        // Set volume to ensure it's not muted
        player?.volume = 1.0
        
        // Setup observers
        setupPlayerObservers()
        
        // Start playing immediately
        connectionStatus = "Buffering..."
        isBuffering = true
        player?.play()
        isPlaying = true
        print("Attempting to play: \(stationName)")
        print("Volume set to: \(player?.volume ?? 0)")
    }
    
    private func setupPlayerObservers() {
        // Observe player status
        statusObserver = playerItem?.observe(\.status, options: [.new]) { [weak self] item, _ in
            Task { @MainActor [weak self] in
                guard let self = self else { return }
                switch item.status {
                case .readyToPlay:
                    print("Player ready to play")
                    self.connectionStatus = "Connected & Playing"
                    self.isBuffering = false
                    self.player?.play()
                    self.isPlaying = true
                case .failed:
                    let errorDesc = item.error?.localizedDescription ?? "Unknown error"
                    print("Player failed: \(errorDesc)")
                    self.errorMessage = "Playback failed: \(errorDesc)"
                    self.connectionStatus = "Failed"
                    self.isPlaying = false
                case .unknown:
                    print("Player status unknown")
                    self.connectionStatus = "Connecting..."
                    self.isBuffering = true
                @unknown default:
                    break
                }
            }
        }
        
        // Add time observer to detect actual playback
        let interval = CMTime(seconds: 1, preferredTimescale: 1)
        timeObserver = player?.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak self] time in
            guard let self = self else { return }
            if time.seconds > 0 {
                self.connectionStatus = "STREAMING ACTIVE (time: \(Int(time.seconds))s)"
                print("Audio time progressing: \(time.seconds)s - STREAM IS WORKING!")
            }
        }
    }

    func pause() {
        player?.pause()
        isPlaying = false
        connectionStatus = "Paused"
        isBuffering = false
        if let observer = timeObserver {
            player?.removeTimeObserver(observer)
            timeObserver = nil
        }
        print("Playback paused")
    }

    func togglePlayPause() {
        if isPlaying {
            pause()
        } else if let name = currentStationName, let image = currentStationImage {
            Task { await play(stationName: name, imageName: image) }
        }
    }

    func setVolume(_ value: Float) {
        player?.volume = value
        print("Volume set to: \(value)")
    }
    
    func playNext() {
        guard !stationList.isEmpty else { return }
        currentStationIndex = (currentStationIndex + 1) % stationList.count
        let station = stationList[currentStationIndex]
        Task {
            await play(stationName: station.name, imageName: station.image)
        }
    }
    
    func playPrevious() {
        guard !stationList.isEmpty else { return }
        currentStationIndex = (currentStationIndex - 1 + stationList.count) % stationList.count
        let station = stationList[currentStationIndex]
        Task {
            await play(stationName: station.name, imageName: station.image)
        }
    }
    
    private func addToRecentlyPlayed(name: String, image: String) {
        // Remove if already exists
        recentlyPlayed.removeAll { $0.name == name }
        
        // Add to beginning
        recentlyPlayed.insert((name: name, image: image), at: 0)
        
        // Keep only last 10 stations
        if recentlyPlayed.count > 10 {
            recentlyPlayed = Array(recentlyPlayed.prefix(10))
        }
        
        // Save to UserDefaults
        saveRecentlyPlayed()
    }
    
    private func saveRecentlyPlayed() {
        let data = recentlyPlayed.map { ["name": $0.name, "image": $0.image] }
        UserDefaults.standard.set(data, forKey: "recentlyPlayed")
    }
    
    private func loadRecentlyPlayed() {
        if let data = UserDefaults.standard.array(forKey: "recentlyPlayed") as? [[String: String]] {
            recentlyPlayed = data.compactMap { dict in
                guard let name = dict["name"], let image = dict["image"] else { return nil }
                return (name: name, image: image)
            }
        }
    }
    
    deinit {
        statusObserver?.invalidate()
        if let observer = timeObserver {
            player?.removeTimeObserver(observer)
        }
    }
}

