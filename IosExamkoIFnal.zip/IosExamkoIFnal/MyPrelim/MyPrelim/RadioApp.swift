import SwiftUI

@main
struct RadioApp: App {
    @StateObject private var appState = AppState()
    
    init() {
        // Initialize Supabase service
        SupabaseService.shared.configure(
            url: SupabaseConfig.projectURL,
            anonKey: SupabaseConfig.anonKey
        )
        print("Supabase configured: \(SupabaseConfig.projectURL)")
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(appState)
        }
    }
}
