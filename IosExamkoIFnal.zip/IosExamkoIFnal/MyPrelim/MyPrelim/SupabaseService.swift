import Foundation
import Combine

/// Main Supabase service for handling database operations
class SupabaseService {
    static let shared = SupabaseService()
    
    private var projectURL: String = ""
    private var anonKey: String = ""
    private let session = URLSession.shared
    
    /// Initialize Supabase service with your credentials
    func configure(url: String, anonKey: String) {
        self.projectURL = url
        self.anonKey = anonKey
    }
    
    // MARK: - User Operations
    
    /// Fetch all users from Supabase
    func fetchUsers() async throws -> [SupabaseUser] {
        guard !projectURL.isEmpty, !anonKey.isEmpty else {
            throw SupabaseError.notConfigured
        }
        
        let endpoint = "\(projectURL)/rest/v1/users?select=*"
        var request = URLRequest(url: URL(string: endpoint)!)
        request.httpMethod = "GET"
        request.setValue("Bearer \(anonKey)", forHTTPHeaderField: "Authorization")
        request.setValue(anonKey, forHTTPHeaderField: "apikey")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let (data, response) = try await session.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw SupabaseError.requestFailed
        }
        
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let users = try decoder.decode([SupabaseUser].self, from: data)
        return users
    }
    
    /// Create a new user in Supabase
    func createUser(_ user: SupabaseUser) async throws -> SupabaseUser {
        guard !projectURL.isEmpty, !anonKey.isEmpty else {
            throw SupabaseError.notConfigured
        }
        
        let endpoint = "\(projectURL)/rest/v1/users"
        var request = URLRequest(url: URL(string: endpoint)!)
        request.httpMethod = "POST"
        request.setValue("Bearer \(anonKey)", forHTTPHeaderField: "Authorization")
        request.setValue(anonKey, forHTTPHeaderField: "apikey")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("return=representation", forHTTPHeaderField: "Prefer")
        
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        request.httpBody = try encoder.encode(user)
        
        print("POST to: \(endpoint)")
        print("Request body: \(String(data: request.httpBody ?? Data(), encoding: .utf8) ?? "nil")")
        
        let (data, response) = try await session.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse else {
            print("Invalid response type")
            throw SupabaseError.requestFailed
        }
        
        let responseBody = String(data: data, encoding: .utf8) ?? "nil"
        print("Response status: \(httpResponse.statusCode)")
        print("Response body: \(responseBody)")
        
        guard (httpResponse.statusCode == 200 || httpResponse.statusCode == 201) else {
            print("Request failed with status: \(httpResponse.statusCode)")
            throw SupabaseError.requestFailed
        }
        
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let responseArray = try decoder.decode([SupabaseUser].self, from: data)
        guard let createdUser = responseArray.first else {
            throw SupabaseError.decodingFailed
        }
        return createdUser
    }
    
    /// Update an existing user in Supabase
    func updateUser(_ user: SupabaseUser) async throws -> SupabaseUser {
        guard !projectURL.isEmpty, !anonKey.isEmpty else {
            throw SupabaseError.notConfigured
        }
        
        guard let id = user.id else {
            throw SupabaseError.invalidData
        }
        
        let endpoint = "\(projectURL)/rest/v1/users?id=eq.\(id)"
        var request = URLRequest(url: URL(string: endpoint)!)
        request.httpMethod = "PATCH"
        request.setValue("Bearer \(anonKey)", forHTTPHeaderField: "Authorization")
        request.setValue(anonKey, forHTTPHeaderField: "apikey")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("return=representation", forHTTPHeaderField: "Prefer")
        
        // Create update payload without the id field (it's auto-generated and can't be updated)
        let updatePayload: [String: Any?] = [
            "username": user.username,
            "password": user.password,
            "email": user.email,
            "profile_image": user.profileImage
        ]
        
        request.httpBody = try JSONSerialization.data(withJSONObject: updatePayload, options: [])
        
        print("PATCH to: \(endpoint)")
        print("Request body: \(String(data: request.httpBody ?? Data(), encoding: .utf8) ?? "nil")")
        
        let (data, response) = try await session.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse else {
            print("Invalid response type")
            throw SupabaseError.requestFailed
        }
        
        let responseBody = String(data: data, encoding: .utf8) ?? "nil"
        print("Response status: \(httpResponse.statusCode)")
        print("Response body: \(responseBody)")
        
        guard httpResponse.statusCode == 200 else {
            print("Update failed with status: \(httpResponse.statusCode)")
            throw SupabaseError.requestFailed
        }
        
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        let responseArray = try decoder.decode([SupabaseUser].self, from: data)
        guard let updatedUser = responseArray.first else {
            throw SupabaseError.decodingFailed
        }
        return updatedUser
    }
    
    /// Delete a user from Supabase
    func deleteUser(id: Int) async throws {
        guard !projectURL.isEmpty, !anonKey.isEmpty else {
            throw SupabaseError.notConfigured
        }
        
        let endpoint = "\(projectURL)/rest/v1/users?id=eq.\(id)"
        var request = URLRequest(url: URL(string: endpoint)!)
        request.httpMethod = "DELETE"
        request.setValue("Bearer \(anonKey)", forHTTPHeaderField: "Authorization")
        request.setValue(anonKey, forHTTPHeaderField: "apikey")
        
        let (_, response) = try await session.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 204 else {
            throw SupabaseError.requestFailed
        }
    }
}

// MARK: - Models

/// Supabase-compatible User model
struct SupabaseUser: Codable, Identifiable {
    let id: Int?
    let username: String
    let password: String
    let email: String?
    let profileImage: String?  // Store as base64 or URL
    let createdAt: String?
    let updatedAt: String?
    
    enum CodingKeys: String, CodingKey {
        case id
        case username
        case password
        case email
        case profileImage = "profile_image"
        case createdAt = "created_at"
        case updatedAt = "updated_at"
    }
    
    /// Convert from local User model to Supabase model
    init(from user: User) {
        self.id = nil
        self.username = user.username
        self.password = user.password
        self.email = user.email
        self.profileImage = user.profileImage.map { data in
            data.base64EncodedString()
        }
        self.createdAt = nil
        self.updatedAt = nil
    }
    
    /// Initialize for creation/update
    init(id: Int? = nil, username: String, password: String, email: String? = nil, 
         profileImage: String? = nil, createdAt: String? = nil, updatedAt: String? = nil) {
        self.id = id
        self.username = username
        self.password = password
        self.email = email
        self.profileImage = profileImage
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
}

// MARK: - Error Handling

enum SupabaseError: LocalizedError {
    case notConfigured
    case requestFailed
    case decodingFailed
    case invalidData
    case networkError(Error)
    
    var errorDescription: String? {
        switch self {
        case .notConfigured:
            return "Supabase service is not configured. Call configure(url:anonKey:) first."
        case .requestFailed:
            return "The request to Supabase failed."
        case .decodingFailed:
            return "Failed to decode response from Supabase."
        case .invalidData:
            return "Invalid data provided."
        case .networkError(let error):
            return "Network error: \(error.localizedDescription)"
        }
    }
}
