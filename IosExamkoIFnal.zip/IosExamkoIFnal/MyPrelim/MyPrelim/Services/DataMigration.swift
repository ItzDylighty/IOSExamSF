import Foundation

/// Handles migration of data from Supabase
class DataMigration {
    private let supabaseService: SupabaseService
    
    init(supabaseService: SupabaseService = .shared) {
        self.supabaseService = supabaseService
    }
    
    // MARK: - Migration Operations
    
    /// Migrate all users to Supabase
    /// - Parameters:
    ///   - users: Array of users
    ///   - progressHandler: Closure called with (completed, total) for progress tracking
    /// - Returns: Array of successfully migrated users
    func migrateUsersToSupabase(
        users: [User],
        progressHandler: ((Int, Int) -> Void)? = nil
    ) async throws -> [SupabaseUser] {
        var migratedUsers: [SupabaseUser] = []
        
        for (index, user) in users.enumerated() {
            do {
                let supabaseUser = SupabaseUser(from: user)
                let createdUser = try await supabaseService.createUser(supabaseUser)
                migratedUsers.append(createdUser)
                progressHandler?(index + 1, users.count)
            } catch {
                print("Failed to migrate user \(user.username): \(error.localizedDescription)")
                // Continue with next user instead of throwing
            }
        }
        
        return migratedUsers
    }
    
    /// Sync a single user to Supabase
    func syncUserToSupabase(_ user: User) async throws -> SupabaseUser {
        let supabaseUser = SupabaseUser(from: user)
        return try await supabaseService.createUser(supabaseUser)
    }
    
    /// Fetch users from Supabase and convert to local User model
    func fetchUsersFromSupabase() async throws -> [User] {
        let supabaseUsers = try await supabaseService.fetchUsers()
        return supabaseUsers.map { User(from: $0) }
    }
}

// Note: User conversion extension is now in Model.swift

// MARK: - Migration Status Tracking

/// Tracks the status of data migration
class MigrationStatus: ObservableObject {
    @Published var isRunning = false
    @Published var progress: Double = 0
    @Published var currentUser: String = ""
    @Published var totalUsers: Int = 0
    @Published var completedUsers: Int = 0
    @Published var errorMessage: String?
    @Published var successMessage: String?
    
    func reset() {
        isRunning = false
        progress = 0
        currentUser = ""
        totalUsers = 0
        completedUsers = 0
        errorMessage = nil
        successMessage = nil
    }
    
    func updateProgress(completed: Int, total: Int) {
        completedUsers = completed
        totalUsers = total
        progress = total > 0 ? Double(completed) / Double(total) : 0
    }
}
