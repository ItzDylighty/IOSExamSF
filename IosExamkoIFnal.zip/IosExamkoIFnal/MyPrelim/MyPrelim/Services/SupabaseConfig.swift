import Foundation

/// Supabase Configuration
/// 
/// To get your credentials:
/// 1. Go to https://app.supabase.com
/// 2. Select your project
/// 3. Go to Settings → API
/// 4. Copy the Project URL and anon key
///
/// IMPORTANT: For production, use environment variables or secure storage
/// Never hardcode sensitive credentials in your app
struct SupabaseConfig {
    
    // ⚠️ REPLACE THESE WITH YOUR ACTUAL CREDENTIALS
    static let projectURL = "https://dijlkkeheqthsjitsxdw.supabase.co"
    static let anonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRpamxra2VoZXF0aHNqaXRzeGR3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMzNTY0ODUsImV4cCI6MjA3ODkzMjQ4NX0.AcVpArY1ebCNQ8A17wAOKc_TVIZhKHuG-9ChN1Nx0mg"
    
    /// Validate configuration
    static func validate() -> Bool {
        let isConfigured = !projectURL.contains("YOUR_PROJECT_ID") && 
                          !anonKey.contains("YOUR_ANON_KEY")
        
        if !isConfigured {
            print("⚠️ WARNING: Supabase is not configured!")
            print("Please update SupabaseConfig.swift with your credentials")
        }
        
        return isConfigured
    }
}

// MARK: - Environment-based Configuration (Optional)

/// For production, use this approach with environment variables
struct SupabaseEnvironmentConfig {
    
    /// Get configuration from environment variables
    /// Set these in your build scheme or CI/CD pipeline
    static func fromEnvironment() -> (url: String, key: String)? {
        guard let url = ProcessInfo.processInfo.environment["SUPABASE_URL"],
              let key = ProcessInfo.processInfo.environment["SUPABASE_ANON_KEY"] else {
            return nil
        }
        return (url, key)
    }
    
    /// Get configuration from Info.plist
    static func fromPlist() -> (url: String, key: String)? {
        guard let url = Bundle.main.infoDictionary?["SUPABASE_URL"] as? String,
              let key = Bundle.main.infoDictionary?["SUPABASE_ANON_KEY"] as? String else {
            return nil
        }
        return (url, key)
    }
}

// MARK: - Secure Storage (Keychain)

import Security

/// Store and retrieve credentials securely from Keychain
class KeychainManager {
    static let shared = KeychainManager()
    
    private let service = "com.myapp.supabase"
    
    /// Save credential to Keychain
    func save(_ value: String, forKey key: String) -> Bool {
        guard let data = value.data(using: .utf8) else { return false }
        
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key,
            kSecValueData as String: data
        ]
        
        SecItemDelete(query as CFDictionary)
        return SecItemAdd(query as CFDictionary, nil) == errSecSuccess
    }
    
    /// Retrieve credential from Keychain
    func retrieve(forKey key: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key,
            kSecReturnData as String: true
        ]
        
        var result: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        
        guard status == errSecSuccess,
              let data = result as? Data,
              let string = String(data: data, encoding: .utf8) else {
            return nil
        }
        
        return string
    }
    
    /// Delete credential from Keychain
    func delete(forKey key: String) -> Bool {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key
        ]
        
        return SecItemDelete(query as CFDictionary) == errSecSuccess
    }
}

// MARK: - Setup Instructions

/*
 
 SETUP INSTRUCTIONS:
 
 1. Go to https://app.supabase.com and create a new project
 
 2. Once your project is ready, go to Settings → API
 
 3. Copy your credentials:
    - Project URL (looks like: https://xxxxx.supabase.co)
    - anon public key (long string starting with eyJ...)
 
 4. Replace the placeholder values in this file:
    - projectURL = "https://YOUR_PROJECT_ID.supabase.co"
    - anonKey = "YOUR_ANON_KEY_HERE"
 
 5. In your app initialization (RadioApp.swift), add:
 
    @main
    struct RadioApp: App {
        var body: some Scene {
            WindowGroup {
                Root()
                    .onAppear {
                        SupabaseService.shared.configure(
                            url: SupabaseConfig.projectURL,
                            anonKey: SupabaseConfig.anonKey
                        )
                    }
            }
        }
    }
 
 6. Create the users table in Supabase (see SUPABASE_SETUP.md)
 
 7. Run your app and use SupabaseMigrationView to migrate data
 
 SECURITY NOTES:
 - For development: Current setup is fine
 - For production: Use environment variables or Keychain
 - Never commit credentials to version control
 - Use .gitignore to exclude sensitive files
 
 */
