import Foundation

/// User model - now using Supabase as the source of truth
final class User: Identifiable {
    let id: Int?
    var username: String
    var password: String
    var email: String?
    var profileImage: Data?        

    init(id: Int? = nil, username: String, password: String, email: String? = nil, profileImage: Data? = nil) {
        self.id = id
        self.username = username
        self.password = password
        self.email = email
        self.profileImage = profileImage
    }
    
    /// Initialize from Supabase user model
    convenience init(from supabaseUser: SupabaseUser) {
        let profileImageData: Data? = supabaseUser.profileImage.flatMap { base64String in
            Data(base64Encoded: base64String)
        }
        
        self.init(
            id: supabaseUser.id,
            username: supabaseUser.username,
            password: supabaseUser.password,
            email: supabaseUser.email,
            profileImage: profileImageData
        )
    }
}


