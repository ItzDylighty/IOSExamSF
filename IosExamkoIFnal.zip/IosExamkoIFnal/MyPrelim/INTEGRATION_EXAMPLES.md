# Integration Examples

This document shows how to integrate Supabase into your existing views.

## 1. Update Login View

Replace the `loginUser()` function in `Login.swift`:

### Before (SwiftData only):
```swift
private func loginUser() {
    if let user = users.first(where: { $0.username == username && $0.password == password }) {
        UserDefaults.standard.set(user.username, forKey: "currentUsername")
        appState.isLoggedIn = true
        showLoginSuccessAlert = true
    } else {
        showLoginErrorAlert = true
    }
}
```

### After (Supabase):
```swift
private func loginUser() {
    Task {
        do {
            let supabaseUsers = try await SupabaseService.shared.fetchUsers()
            
            if let user = supabaseUsers.first(where: { 
                $0.username == username && $0.password == password 
            }) {
                UserDefaults.standard.set(user.username, forKey: "currentUsername")
                DispatchQueue.main.async {
                    appState.isLoggedIn = true
                    showLoginSuccessAlert = true
                }
            } else {
                DispatchQueue.main.async {
                    showLoginErrorAlert = true
                }
            }
        } catch {
            DispatchQueue.main.async {
                showLoginErrorAlert = true
            }
        }
    }
}
```

## 2. Update Signup View

Replace the `createAccount()` function in `Login.swift`:

### Before (SwiftData only):
```swift
private func createAccount() {
    guard password == reEnterPassword, !password.isEmpty else {
        showPasswordMismatchAlert = true
        return
    }
    
    if users.contains(where: { $0.username == username }) {
        showUserExistsAlert = true
        return
    }

    let newUser = User(username: username, password: password)
    context.insert(newUser)
    try? context.save()
    dismiss()
}
```

### After (Supabase):
```swift
private func createAccount() {
    guard password == reEnterPassword, !password.isEmpty else {
        showPasswordMismatchAlert = true
        return
    }
    
    Task {
        do {
            let supabaseUsers = try await SupabaseService.shared.fetchUsers()
            
            if supabaseUsers.contains(where: { $0.username == username }) {
                DispatchQueue.main.async {
                    showUserExistsAlert = true
                }
                return
            }

            let newUser = SupabaseUser(
                username: username,
                password: password
            )
            
            try await SupabaseService.shared.createUser(newUser)
            
            // Also save locally for offline support
            let localUser = User(username: username, password: password)
            context.insert(localUser)
            try? context.save()
            
            DispatchQueue.main.async {
                dismiss()
            }
        } catch {
            DispatchQueue.main.async {
                print("Error creating account: \(error)")
            }
        }
    }
}
```

## 3. Update Profile View

Add sync functionality to `Profile.swift`:

```swift
struct ProfileView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.modelContext) private var context
    @Query private var users: [User]
    
    @State private var username: String = ""
    @State private var email: String = ""
    @State private var profileImageData: Data? = nil
    @State private var isSyncing = false
    @State private var syncMessage: String?
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 28) {
                    // ... existing UI ...
                    
                    // Add Sync Button
                    Button(action: syncProfileToSupabase) {
                        HStack {
                            Image(systemName: "cloud.arrow.up")
                            Text(isSyncing ? "Syncing..." : "Sync to Cloud")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    .disabled(isSyncing)
                    
                    if let message = syncMessage {
                        Text(message)
                            .font(.caption)
                            .foregroundColor(.green)
                    }
                }
            }
        }
        .onAppear(perform: loadProfile)
    }
    
    private func loadProfile() {
        if let currentUsername = UserDefaults.standard.string(forKey: "currentUsername"),
           let user = users.first(where: { $0.username == currentUsername }) {
            username = user.username
            email = user.email ?? ""
            profileImageData = user.profileImage
        }
    }
    
    private func syncProfileToSupabase() {
        guard let currentUsername = UserDefaults.standard.string(forKey: "currentUsername"),
              let user = users.first(where: { $0.username == currentUsername }) else {
            return
        }
        
        Task {
            isSyncing = true
            
            do {
                // Update local model
                user.email = email
                user.profileImage = profileImageData
                try? context.save()
                
                // Sync to Supabase
                let supabaseUser = SupabaseUser(from: user)
                try await SupabaseService.shared.createUser(supabaseUser)
                
                DispatchQueue.main.async {
                    syncMessage = "Profile synced successfully!"
                    isSyncing = false
                    
                    // Clear message after 3 seconds
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                        syncMessage = nil
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    syncMessage = "Sync failed: \(error.localizedDescription)"
                    isSyncing = false
                }
            }
        }
    }
}
```

## 4. Add Settings View with Migration

Create a new settings view:

```swift
struct SettingsView: View {
    @State private var showMigrationView = false
    
    var body: some View {
        NavigationStack {
            List {
                Section("Cloud Sync") {
                    NavigationLink(destination: SupabaseMigrationView()) {
                        HStack {
                            Image(systemName: "cloud.arrow.up")
                                .foregroundColor(.blue)
                            Text("Migrate to Supabase")
                        }
                    }
                    
                    NavigationLink(destination: SyncStatusView()) {
                        HStack {
                            Image(systemName: "arrow.triangle.2.circlepath")
                                .foregroundColor(.green)
                            Text("Sync Status")
                        }
                    }
                }
                
                Section("About") {
                    Text("Version 1.0.0")
                }
            }
            .navigationTitle("Settings")
        }
    }
}

struct SyncStatusView: View {
    @State private var lastSyncTime: String?
    @State private var isLoading = true
    
    var body: some View {
        VStack(spacing: 16) {
            if isLoading {
                ProgressView()
            } else if let lastSync = lastSyncTime {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Last Sync")
                        .font(.headline)
                    Text(lastSync)
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(8)
            }
            
            Spacer()
        }
        .padding()
        .navigationTitle("Sync Status")
        .onAppear(perform: checkSyncStatus)
    }
    
    private func checkSyncStatus() {
        Task {
            do {
                let users = try await SupabaseService.shared.fetchUsers()
                DispatchQueue.main.async {
                    let formatter = DateFormatter()
                    formatter.dateStyle = .medium
                    formatter.timeStyle = .short
                    lastSyncTime = formatter.string(from: Date())
                    isLoading = false
                }
            } catch {
                DispatchQueue.main.async {
                    lastSyncTime = "Failed to check sync status"
                    isLoading = false
                }
            }
        }
    }
}
```

## 5. Add Offline Support

Create a sync manager for offline support:

```swift
class SyncManager: ObservableObject {
    @Published var pendingChanges: [String: Any] = [:]
    @Published var isSyncing = false
    
    private let userDefaults = UserDefaults.standard
    private let key = "pendingChanges"
    
    init() {
        loadPendingChanges()
    }
    
    func addPendingChange(_ change: [String: Any], forKey key: String) {
        pendingChanges[key] = change
        savePendingChanges()
    }
    
    func syncPendingChanges() async {
        guard !pendingChanges.isEmpty else { return }
        
        isSyncing = true
        
        for (key, change) in pendingChanges {
            do {
                // Sync each pending change
                // Implementation depends on your data structure
                pendingChanges.removeValue(forKey: key)
                savePendingChanges()
            } catch {
                print("Failed to sync change: \(error)")
            }
        }
        
        isSyncing = false
    }
    
    private func savePendingChanges() {
        if let encoded = try? JSONEncoder().encode(pendingChanges) {
            userDefaults.set(encoded, forKey: key)
        }
    }
    
    private func loadPendingChanges() {
        if let data = userDefaults.data(forKey: key),
           let decoded = try? JSONDecoder().decode([String: Any].self, from: data) {
            pendingChanges = decoded
        }
    }
}
```

## 6. Add Network Status Monitoring

Monitor network connectivity:

```swift
import Network

class NetworkMonitor: ObservableObject {
    @Published var isConnected = true
    
    private let monitor = NWPathMonitor()
    private let queue = DispatchQueue(label: "NetworkMonitor")
    
    init() {
        monitor.pathUpdateHandler = { [weak self] path in
            DispatchQueue.main.async {
                self?.isConnected = path.status == .satisfied
            }
        }
        monitor.start(queue: queue)
    }
    
    deinit {
        monitor.cancel()
    }
}
```

Use it in your app:

```swift
@main
struct RadioApp: App {
    @StateObject private var networkMonitor = NetworkMonitor()
    @StateObject private var appState = AppState()
    
    var body: some Scene {
        WindowGroup {
            Root()
                .environmentObject(appState)
                .environmentObject(networkMonitor)
                .onAppear {
                    SupabaseService.shared.configure(
                        url: SupabaseConfig.projectURL,
                        anonKey: SupabaseConfig.anonKey
                    )
                }
        }
    }
}
```

## 7. Error Handling Best Practices

```swift
enum SyncError: LocalizedError {
    case networkUnavailable
    case invalidCredentials
    case serverError(String)
    case localStorageError
    
    var errorDescription: String? {
        switch self {
        case .networkUnavailable:
            return "No internet connection. Changes will sync when online."
        case .invalidCredentials:
            return "Invalid Supabase credentials."
        case .serverError(let message):
            return "Server error: \(message)"
        case .localStorageError:
            return "Failed to save changes locally."
        }
    }
}

func handleSyncError(_ error: Error) {
    if let syncError = error as? SyncError {
        print("Sync Error: \(syncError.errorDescription ?? "Unknown")")
    } else if let supabaseError = error as? SupabaseError {
        print("Supabase Error: \(supabaseError.errorDescription ?? "Unknown")")
    } else {
        print("Unexpected error: \(error.localizedDescription)")
    }
}
```

## Next Steps

1. Start with updating the Login view
2. Then update the Signup view
3. Add Profile sync functionality
4. Implement offline support
5. Add network monitoring
6. Test thoroughly

For more details, see SUPABASE_SETUP.md and SUPABASE_QUICK_START.md
