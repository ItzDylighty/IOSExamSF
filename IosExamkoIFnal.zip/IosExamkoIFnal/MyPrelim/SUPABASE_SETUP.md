# Supabase Integration Guide

This guide walks you through setting up Supabase and migrating your Swift data.

## Step 1: Create a Supabase Project

1. Go to [https://app.supabase.com](https://app.supabase.com)
2. Sign up or log in
3. Click "New Project"
4. Fill in project details:
   - Name: Your project name
   - Database Password: Create a strong password
   - Region: Choose closest to your users
5. Wait for the project to initialize (2-3 minutes)

## Step 2: Create the Users Table

1. In Supabase dashboard, go to **SQL Editor**
2. Click **New Query**
3. Paste the following SQL:

```sql
CREATE TABLE users (
  id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  username TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL,
  email TEXT,
  profile_image TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Enable RLS (Row Level Security)
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Create policy to allow all operations (for development - restrict in production)
CREATE POLICY "Allow all operations" ON users
  FOR ALL
  USING (true)
  WITH CHECK (true);
```

4. Click **Run**

## Step 3: Get Your Credentials

1. Go to **Settings** → **API**
2. Copy:
   - **Project URL** (e.g., `https://xxxxx.supabase.co`)
   - **anon public** key (under Project API keys)

## Step 4: Configure Your App

### Option A: Using Environment Variables (Recommended)

Create a new file `SupabaseConfig.swift`:

```swift
import Foundation

struct SupabaseConfig {
    static let projectURL = "YOUR_PROJECT_URL"
    static let anonKey = "YOUR_ANON_KEY"
}
```

### Option B: Configure in AppDelegate or App

In your `RadioApp.swift` or app initialization:

```swift
import SwiftUI

@main
struct RadioApp: App {
    @StateObject private var appState = AppState()
    
    var body: some Scene {
        WindowGroup {
            Root()
                .environmentObject(appState)
                .onAppear {
                    // Configure Supabase
                    SupabaseService.shared.configure(
                        url: "YOUR_PROJECT_URL",
                        anonKey: "YOUR_ANON_KEY"
                    )
                }
        }
    }
}
```

## Step 5: Migrate Your Data

### Option A: Automatic Migration

Create a migration view:

```swift
import SwiftUI
import SwiftData

struct MigrationView: View {
    @Query private var users: [User]
    @StateObject private var migrationStatus = MigrationStatus()
    
    var body: some View {
        VStack(spacing: 16) {
            Text("Migrate Data to Supabase")
                .font(.headline)
            
            if migrationStatus.isRunning {
                ProgressView(value: migrationStatus.progress)
                Text("\(migrationStatus.completedUsers) / \(migrationStatus.totalUsers)")
                    .font(.caption)
            }
            
            Button(action: startMigration) {
                Text(migrationStatus.isRunning ? "Migrating..." : "Start Migration")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
            .disabled(migrationStatus.isRunning)
            
            if let error = migrationStatus.errorMessage {
                Text("Error: \(error)")
                    .foregroundColor(.red)
                    .font(.caption)
            }
            
            if let success = migrationStatus.successMessage {
                Text(success)
                    .foregroundColor(.green)
                    .font(.caption)
            }
        }
        .padding()
    }
    
    private func startMigration() {
        Task {
            migrationStatus.isRunning = true
            migrationStatus.reset()
            
            do {
                let migration = DataMigration()
                let migratedUsers = try await migration.migrateUsersToSupabase(
                    users: users,
                    progressHandler: { completed, total in
                        DispatchQueue.main.async {
                            migrationStatus.updateProgress(completed: completed, total: total)
                        }
                    }
                )
                
                DispatchQueue.main.async {
                    migrationStatus.successMessage = "Successfully migrated \(migratedUsers.count) users!"
                    migrationStatus.isRunning = false
                }
            } catch {
                DispatchQueue.main.async {
                    migrationStatus.errorMessage = error.localizedDescription
                    migrationStatus.isRunning = false
                }
            }
        }
    }
}
```

### Option B: Manual Migration via SQL

1. Export your SwiftData users as JSON
2. In Supabase SQL Editor, insert them:

```sql
INSERT INTO users (username, password, email, profile_image)
VALUES 
  ('user1', 'password1', 'user1@example.com', NULL),
  ('user2', 'password2', 'user2@example.com', NULL);
```

## Step 6: Update Your Login Logic

Update `Login.swift` to use Supabase:

```swift
private func loginUser() {
    Task {
        do {
            let supabaseUsers = try await SupabaseService.shared.fetchUsers()
            
            if let user = supabaseUsers.first(where: { 
                $0.username == username && $0.password == password 
            }) {
                UserDefaults.standard.set(user.username, forKey: "currentUsername")
                appState.isLoggedIn = true
                showLoginSuccessAlert = true
            } else {
                showLoginErrorAlert = true
            }
        } catch {
            showLoginErrorAlert = true
        }
    }
}
```

## Step 7: Update Signup Logic

Update signup in `Login.swift`:

```swift
private func createAccount() {
    guard password == reEnterPassword, !password.isEmpty else {
        showPasswordMismatchAlert = true
        return
    }
    
    Task {
        do {
            let supabaseUsers = try await SupabaseService.shared.fetchUsers()
            
            if supabaseUsers.contains(where: { $0.username == username }) {
                showUserExistsAlert = true
                return
            }
            
            let newUser = SupabaseUser(
                username: username,
                password: password
            )
            
            try await SupabaseService.shared.createUser(newUser)
            dismiss()
        } catch {
            print("Error creating account: \(error)")
        }
    }
}
```

## Security Considerations

⚠️ **Important for Production:**

1. **Never store passwords in plain text** - Use proper authentication
2. **Enable Row Level Security (RLS)** - Restrict data access
3. **Use Supabase Auth** - Replace manual password handling
4. **Encrypt sensitive data** - Especially profile images
5. **Use HTTPS only** - All connections must be encrypted
6. **Rotate keys regularly** - Change API keys periodically

### Recommended: Use Supabase Auth

Replace manual authentication with Supabase Auth:

```swift
// This is a simplified example
// For production, use supabase-swift library
```

## Troubleshooting

### Connection Issues
- Verify Project URL and API key are correct
- Check internet connection
- Ensure Supabase project is active

### CORS Errors
- Go to Supabase Settings → API → CORS
- Add your app's domain

### Data Not Syncing
- Check RLS policies are correctly configured
- Verify API key has correct permissions
- Check network requests in Xcode debugger

## Next Steps

1. Set up Supabase Auth for proper authentication
2. Implement data encryption for sensitive fields
3. Add backup and recovery procedures
4. Set up monitoring and logging
5. Test thoroughly before production deployment

## Resources

- [Supabase Documentation](https://supabase.com/docs)
- [Supabase Swift Client](https://github.com/supabase-community/supabase-swift)
- [REST API Guide](https://supabase.com/docs/guides/api)
