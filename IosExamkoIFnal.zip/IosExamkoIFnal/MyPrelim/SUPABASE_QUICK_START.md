# Supabase Integration - Quick Start

## 📋 What You Get

Three new files have been added to your project:

1. **SupabaseService.swift** - Main service for API calls to Supabase
2. **DataMigration.swift** - Handles migration from SwiftData to Supabase
3. **SupabaseMigrationView.swift** - UI for performing the migration

## 🚀 Quick Setup (5 minutes)

### 1. Create Supabase Project
- Go to https://app.supabase.com
- Create a new project
- Copy your **Project URL** and **anon key**

### 2. Create Database Table
In Supabase dashboard, go to SQL Editor and run:

```sql
CREATE TABLE users (
  id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  username TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL,
  email TEXT,
  profile_image TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all operations" ON users
  FOR ALL USING (true) WITH CHECK (true);
```

### 3. Configure Your App
Add this to your app initialization (e.g., `RadioApp.swift`):

```swift
@main
struct RadioApp: App {
    var body: some Scene {
        WindowGroup {
            Root()
                .onAppear {
                    SupabaseService.shared.configure(
                        url: "https://YOUR_PROJECT_ID.supabase.co",
                        anonKey: "YOUR_ANON_KEY"
                    )
                }
        }
    }
}
```

### 4. Add Migration UI (Optional)
Add this to your Profile or Settings view:

```swift
NavigationLink(destination: SupabaseMigrationView()) {
    HStack {
        Image(systemName: "cloud.arrow.up")
        Text("Migrate to Supabase")
    }
}
```

### 5. Run Migration
- Build and run your app
- Navigate to the migration view
- Click "Start Migration"
- Wait for completion

## 📊 Data Structure

Your users are stored in Supabase with this structure:

```
users table:
├── id (auto-generated)
├── username (unique)
├── password
├── email
├── profile_image (base64 encoded)
├── created_at
└── updated_at
```

## 🔄 Usage Examples

### Fetch Users from Supabase
```swift
do {
    let users = try await SupabaseService.shared.fetchUsers()
    print("Fetched \(users.count) users")
} catch {
    print("Error: \(error)")
}
```

### Create New User
```swift
let newUser = SupabaseUser(
    username: "john_doe",
    password: "secure_password",
    email: "john@example.com"
)

do {
    let created = try await SupabaseService.shared.createUser(newUser)
    print("User created with ID: \(created.id ?? 0)")
} catch {
    print("Error: \(error)")
}
```

### Update User
```swift
var user = SupabaseUser(...)
user.email = "newemail@example.com"

do {
    let updated = try await SupabaseService.shared.updateUser(user)
    print("User updated")
} catch {
    print("Error: \(error)")
}
```

### Delete User
```swift
do {
    try await SupabaseService.shared.deleteUser(id: 123)
    print("User deleted")
} catch {
    print("Error: \(error)")
}
```

## 🔐 Security Tips

### For Development:
✓ Current setup is fine for testing

### For Production:
1. **Use Supabase Auth** instead of manual passwords
2. **Enable RLS policies** to restrict data access
3. **Never expose your anon key** in client code
4. **Use environment variables** for credentials
5. **Encrypt sensitive data** like passwords
6. **Implement proper authentication flow**

## 🐛 Troubleshooting

### "Not configured" error
→ Call `SupabaseService.shared.configure()` before using

### "Request failed" error
→ Check your Project URL and API key are correct

### CORS errors
→ Go to Supabase Settings → API → CORS and add your domain

### Data not syncing
→ Verify RLS policies allow your operations

## 📚 Next Steps

1. **Update Login** - Use Supabase for authentication
2. **Update Signup** - Create users in Supabase
3. **Sync Profile** - Save profile changes to Supabase
4. **Add Offline Support** - Cache data locally
5. **Implement Auth** - Use Supabase Auth SDK

## 🔗 Resources

- [Supabase Docs](https://supabase.com/docs)
- [REST API Reference](https://supabase.com/docs/guides/api)
- [Swift Integration Guide](https://supabase.com/docs/reference/swift/introduction)

## 📝 File Reference

### SupabaseService.swift
Main service class with methods:
- `configure(url:anonKey:)` - Initialize service
- `fetchUsers()` - Get all users
- `createUser(_:)` - Create new user
- `updateUser(_:)` - Update existing user
- `deleteUser(id:)` - Delete user

### DataMigration.swift
Migration helper with:
- `migrateUsersToSupabase(users:progressHandler:)` - Bulk migrate
- `syncUserToSupabase(_:)` - Sync single user
- `fetchUsersFromSupabase()` - Fetch and convert

### SupabaseMigrationView.swift
Pre-built UI with:
- Progress tracking
- Error handling
- Success messages
- User-friendly interface

## ✅ Verification Checklist

- [ ] Supabase project created
- [ ] Database table created
- [ ] Project URL and API key copied
- [ ] App configured with credentials
- [ ] Migration completed successfully
- [ ] Users visible in Supabase dashboard
- [ ] Can fetch users from app

## 💡 Tips

- Test with a small number of users first
- Keep your API key secure
- Monitor Supabase usage in dashboard
- Set up backups regularly
- Test thoroughly before production

---

**Need help?** Check SUPABASE_SETUP.md for detailed instructions.
